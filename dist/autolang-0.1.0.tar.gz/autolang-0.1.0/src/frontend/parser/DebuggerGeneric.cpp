#ifndef DEBUGGER_GENERIC_CPP
#define DEBUGGER_GENERIC_CPP

#include "frontend/ACompiler.hpp"
#include "frontend/parser/Debugger.hpp"
#include "frontend/parser/ParserContext.hpp"
#include "shared/ClassFlags.hpp"
#include <memory>

namespace AutoLang {

ClassId loadClassGenerics(in_func, std::string &name,
                          ClassDeclaration *classDeclaration) {
	auto it =
	    context.defaultClassMap.find(classDeclaration->baseClassLexerStringId);
	if (it == context.defaultClassMap.end()) {
		classDeclaration->throwError(
		    "Bug: Cannot find class " +
		    context.lexerString[classDeclaration->baseClassLexerStringId]);
	}
	ClassId classId = it->second;
	auto clazz = compile.classes[it->second];
	auto classInfo = context.classInfo[it->second];
	{
		auto it = compile.classMap.find(name);
		if (it != compile.classMap.end()) {
			return it->second;
		}
	}
	if (!classInfo->genericData) {
		classDeclaration->throwError(clazz->getName(compile) +
		                             " is not generic");
	}
	auto baseCreateClassNode = context.findCreateClassNode(clazz->id);
	LexerStringId newNameId = context.createLexerStringIfNotExists(name);

	auto newCreateClassNode = context.newClasses.push(
	    baseCreateClassNode->line, newNameId, baseCreateClassNode->classFlags);
	newCreateClassNode->pushClass(in_data);
	// std::cerr << "CLASS " << context.lexerString[newNameId] << "\n";
	newCreateClassNode->superDeclaration =
	    baseCreateClassNode->superDeclaration;
	auto newClassId = newCreateClassNode->classId;
	context.defaultClassMap[newNameId] = newClassId;
	context.newDefaultClassesMap[newClassId] = newCreateClassNode;

	std::vector<ClassDeclaration *> genericTypeId;
	genericTypeId.reserve(classInfo->genericData->genericDeclarations.size());

	for (size_t i = 0; i < classInfo->genericData->genericDeclarations.size();
	     ++i) {
		auto &genericDeclaration =
		    classInfo->genericData->genericDeclarations[i];
		auto &inputClass = classDeclaration->inputClassId[i];

		ClassId inputClassId = *inputClass->classId;

		// Change callnode name
		if (!genericDeclaration->allCallNodes.empty()) {
			const std::string &name =
			    compile.classes[inputClassId]->getName(compile);
			auto nameId = context.createLexerStringIfNotExists(name);
			for (auto *callNode : genericDeclaration->allCallNodes) {
				callNode->nameId = nameId;
			}
		}
		// Change generics type
		genericDeclaration->classId = inputClassId;
		genericDeclaration->nullable = inputClass->nullable;
		ClassDeclaration *newClassDeclaration;
		if (inputClass->isGeneric) {
			newClassDeclaration = context.classDeclarationAllocator.push();
			newClassDeclaration->classId = inputClassId;
			newClassDeclaration->nullable = inputClass->nullable;
			newClassDeclaration->line = genericDeclaration->line;
			if (inputClassId == DefaultClass::functionClassId) {
				newClassDeclaration->inputClassId.reserve(
				    inputClass->inputClassId.size());
				for (auto classDeclaration : inputClass->inputClassId) {
					newClassDeclaration->inputClassId.push_back(
					    classDeclaration->copy(in_data));
				}
			}
		} else {
			newClassDeclaration = inputClass;
		}

		genericTypeId.push_back(newClassDeclaration);

		if (genericDeclaration->condition) {
			auto &condition = *genericDeclaration->condition;
			// if (condition.condition ==
			// GenericDeclarationCondition::MUST_EXTENDS) {
			if (!condition.classDeclaration->classId) {
				condition.classDeclaration->load<true>(in_data);
				if (!condition.classDeclaration->classId) {
					condition.classDeclaration->throwError(
					    "Unresolved " +
					    condition.classDeclaration->getName(in_data));
				}
			} else if (condition.classDeclaration->classId ==
			           DefaultClass::functionClassId) {
				condition.classDeclaration->load<true>(in_data);
			}
			context.checkValidateExtends[genericDeclaration].push_back(
			    newClassDeclaration);
			// }
		}

		for (auto *classDeclaration :
		     genericDeclaration->allClassDeclarations) {
			classDeclaration->classId = inputClassId;
			classDeclaration->inputClassId = newClassDeclaration->inputClassId;
			if (classDeclaration->mustInference) {
				classDeclaration->nullable = inputClass->nullable;
				// classDeclaration->mustInference = false;
			}
			classDeclaration->baseClassLexerStringId =
			    inputClass->baseClassLexerStringId;
		}
	}

	for (auto &[classDeclaration, node] :
	     classInfo->genericData->mustRenameNodes) {
		if (!classDeclaration->classId) {
			classDeclaration->load<false, true>(in_data);
			if (!classDeclaration->classId) {
				classDeclaration->throwError(
				    "Unsolved " + classDeclaration->getName(in_data));
			}
		}
		auto name = classDeclaration->getName(in_data);
		switch (node->kind) {
			case NodeType::UNKNOW: {
				auto unknowNode = static_cast<UnknowNode *>(node);
				auto it = context.lexerStringMap.find(name);
				if (it == context.lexerStringMap.end()) {
					classDeclaration->throwError("Unsolved " + name);
				}
				unknowNode->nameId = it->second;
				break;
			}
			case NodeType::CALL: {
				auto callNode = static_cast<CallNode *>(node);
				auto it = context.lexerStringMap.find(name);
				if (it == context.lexerStringMap.end()) {
					classDeclaration->throwError("Unsolved " + name);
				}
				callNode->nameId = it->second;
				break;
			}
			default:
				break;
		}
		classDeclaration->classId = std::nullopt;
	}

	auto newClass = compile.classes[newClassId];
	newClass->memberMap = clazz->memberMap;
	auto newClassInfo = context.classInfo[newClassId];
	newClassInfo->memberMap = classInfo->memberMap;
	newClass->genericType.offset = compile.allGenericType.size();
	newClass->genericType.size = genericTypeId.size();
	newClass->genericBaseClassId = classId;
	for (auto genericType : genericTypeId) {
		compile.allGenericType.push_back(*genericType->classId);
		compile.allGenericTypeNullable.push_back(genericType->nullable);
	}
	newClassInfo->genericTypeId = std::move(genericTypeId);
	newClassInfo->declarationThis = context.declarationNodePool.push(
	    classInfo->declarationThis->line, newClassId, lexerIdthis, "this",
	    nullptr, true, false, false);
	newClassInfo->declarationThis->id = 0;
	newClassInfo->declarationThis->classId = newClassId;
	auto lastCurrentClassId = context.currentClassId;
	context.currentClassId = newClassId;

	// std::cerr << "Created " << newClass->getName(compile) << "\n ";

	if (newCreateClassNode->superDeclaration &&
	    !newCreateClassNode->superDeclaration->classId) {
		newCreateClassNode->superDeclaration->load<true>(in_data);
		// std::cerr << "Created "
		//           << newCreateClassNode->superDeclaration->getName(in_data)
		//           << "\n ";
	}

	for (auto *member : classInfo->member) {
		if (member->classDeclaration) {
			if (!member->classDeclaration->classId) {
				member->classDeclaration->load<true>(in_data);
				if (!member->classDeclaration->classId) {
					classDeclaration->throwError(
					    "Unsolved " +
					    member->classDeclaration->getName(in_data));
				}
			}
			member->classId = *member->classDeclaration->classId;
			member->nullable =
			    member->nullable || member->classDeclaration->nullable;
			if (!member->classDeclaration->isGenerics(in_data)) {
				newClassInfo->member.push_back(member);
				continue;
			}
			// std::cerr
			//     << "Member declaration: "
			//     <<
			//     compile.classes[*member->classDeclaration->classId]->getName(compile)
			//     << "\n";
		} else {
			// std::cerr << "No" << "\n";
		}
		newClassInfo->member.push_back(
		    static_cast<DeclarationNode *>(member->copy(in_data)));
	}

	newClassInfo->declarationThis->classId = newClassId;
	// newClassInfo->func = classInfo->func;
	newClassInfo->staticFunc = classInfo->staticFunc;
	newClass->parentId = clazz->parentId;

	// newClass->funcMap = clazz->funcMap;

	ParserContext::mode = baseCreateClassNode->mode;

	for (auto *declarationNode : classInfo->allDeclarationNode) {
		if (declarationNode->classDeclaration) {
			if (!declarationNode->classDeclaration->classId) {
				declarationNode->classDeclaration->load<false>(in_data);
				if (!declarationNode->classDeclaration->classId) {
					classDeclaration->throwError(
					    "Bug: Cannot find class name " +
					    declarationNode->classDeclaration->getName(in_data));
				}
				// std::cerr << "loaded "
				//           <<
				//           declarationNode->classDeclaration->getName(in_data)
				//           << "\n";
				declarationNode->optimize(in_data);
				declarationNode->classDeclaration->classId = std::nullopt;
				// declarationNode->classDeclaration = nullptr;
				continue;
			}
		}
		declarationNode->optimize(in_data);
		// declarationNode->classDeclaration = nullptr;
	}

	for (auto &[declarationNode, value] :
	     classInfo->genericData->staticDeclaration) {
		auto node = context.makeDeclarationNode(
		    in_data, declarationNode->line, declarationNode->baseName,
		    newClass->getName(compile) + "." +
		        context.lexerString[declarationNode->baseName],
		    declarationNode->classDeclaration, declarationNode->isVal, true,
		    declarationNode->nullable, false, true);
		newClassInfo->staticMember[declarationNode->baseName] = node;
		if (node->classDeclaration) {
			if (!node->classDeclaration->classId) {
				node->classDeclaration->load<false>(in_data);
				if (!node->classDeclaration->classId) {
					classDeclaration->throwError(
					    "Bug: Cannot find class name " +
					    node->classDeclaration->getName(in_data));
				}
				node->optimize(in_data);
				node->classDeclaration->classId = std::nullopt;
				// declarationNode->classDeclaration = nullptr;
			} else {
				node->classId = *node->classDeclaration->classId;
			}
			// std::cerr << "loaded " <<
			// (compile.classes[node->classId]->getName(compile))
			//           << " "
			//           << declarationNode->classDeclaration->getName(in_data)
			//           << "\n";
		}
		node->optimize(in_data);
		if (value) {
			auto varNode =
			    context.varPool.push(declarationNode->line, node, false, true);
			auto setNode = context.setValuePool.push(declarationNode->line,
			                                         varNode, value, true);
			context.staticNode.push_back(setNode);
			// std::cerr << "Added " << node->getName(compile) << "\n";
		}
		// declarationNode->classDeclaration = nullptr;
	}

	newCreateClassNode->body.nodes.reserve(
	    baseCreateClassNode->body.nodes.size());
	for (auto *node : baseCreateClassNode->body.nodes) {
		newCreateClassNode->body.nodes.push_back(node->copy(in_data));
	}

	if (classInfo->primaryConstructor) {
		auto constructor = context.createConstructorPool.push(
		    classInfo->primaryConstructor->line, newClassId, newNameId,
		    classInfo->primaryConstructor->parameter->copy(in_data), true,
		    classInfo->primaryConstructor->functionFlags);
		newClassInfo->primaryConstructor = constructor;
		constructor->pushFunction(in_data);
	} else {
		newClassInfo->secondaryConstructor.reserve(
		    classInfo->secondaryConstructor.size());
		for (auto *constructor : classInfo->secondaryConstructor) {
			auto newConstructor = context.createConstructorPool.push(
			    constructor->line, newClassId, newNameId,
			    constructor->parameter->copy(in_data), false,
			    constructor->functionFlags);
			newClassInfo->secondaryConstructor.push_back(newConstructor);
			newConstructor->pushFunction(in_data);
			// ParserContext::mode = constructor->mode;
			auto lastCurrentFunctionId = context.currentFunctionId;
			context.gotoFunction(newConstructor->funcId);
			newConstructor->body.nodes.reserve(constructor->body.nodes.size());
			for (auto &[declarationNode, value] :
			     context.functionInfo[constructor->funcId]
			         ->reflectDeclarationMap) {
				value = static_cast<DeclarationNode *>(
				    declarationNode->copy(in_data));
			}
			for (auto *node : constructor->body.nodes) {
				newConstructor->body.nodes.push_back(node->copy(in_data));
			}
			context.gotoFunction(lastCurrentFunctionId);
		}
	}

	auto lastCurrentFunctionId = context.currentFunctionId;

	for (auto *createFuncNode : classInfo->createFunctionNodes) {
		auto funcInfo = context.functionInfo[createFuncNode->id];
		// std::cerr << " --- " << context.lexerString[createFuncNode->nameId]
		//           << "\n";
		auto newCreateFuncNode = context.newFunctions.push(
		    createFuncNode->line, createFuncNode->tokenIndex, newClassId,
		    createFuncNode->nameId == lexerId__CLASS__ ? newNameId
		                                               : createFuncNode->nameId,
		    nullptr, createFuncNode->parameter->copy(in_data),
		    createFuncNode->functionFlags);
		if (createFuncNode->functionFlags & FunctionFlags::FUNC_IS_NATIVE) {
			newCreateFuncNode->pushNativeFunction(
			    in_data, compile.functions[createFuncNode->id]->native);
		} else {
			newCreateFuncNode->pushFunction(in_data);
		}
		auto newFunc = compile.functions[newCreateFuncNode->id];
		auto newFuncInfo = context.functionInfo[newCreateFuncNode->id];
		newFunc->returnId = compile.functions[createFuncNode->id]->returnId;
		if (createFuncNode->classDeclaration) {
			if (!createFuncNode->classDeclaration->classId) {
				createFuncNode->classDeclaration->load<false>(in_data);
				if (!createFuncNode->classDeclaration->classId) {
					classDeclaration->throwError(
					    "Bug: Cannot resolve return type of generic function");
				}
				newFunc->returnId = *createFuncNode->classDeclaration->classId;
				createFuncNode->classDeclaration->classId = std::nullopt;
			} else {
				newFunc->returnId = *createFuncNode->classDeclaration->classId;
			}

			if (newFunc->returnId == DefaultClass::functionClassId) {
				newFuncInfo->returnClass =
				    createFuncNode->classDeclaration->copy(in_data);
			}
		}
		context.gotoFunction(newCreateFuncNode->id);
		// ParserContext::mode = createFuncNode->mode; //Loaded in new class
		newFuncInfo->body.nodes.reserve(funcInfo->body.nodes.size());
		for (auto &[declarationNode, value] : funcInfo->reflectDeclarationMap) {
			value =
			    static_cast<DeclarationNode *>(declarationNode->copy(in_data));
		}
		for (auto *node : funcInfo->body.nodes) {
			newFuncInfo->body.nodes.push_back(node->copy(in_data));
		}
		if (funcInfo->inferenceNode) {
			newFuncInfo->inferenceNode =
			    static_cast<ReturnNode *>(newFuncInfo->body.nodes[0]);
			context.mustInferenceFunctionType.push_back(newFunc->id);
		}
	}

	context.gotoFunction(lastCurrentFunctionId);
	context.currentClassId = lastCurrentClassId;

	// std::cerr << "Created " << newClass->getName(compile) << "\n";
	return newClassId;
}

void loadFunctionGenerics(in_func, std::string &name,
                          ClassDeclaration *classDeclaration) {
	auto it = context.genericFunctionMap.find(
	    classDeclaration->baseClassLexerStringId);
	if (it == context.genericFunctionMap.end()) {
		classDeclaration->throwError(
		    "Bug: Cannot find function " +
		    context.lexerString[classDeclaration->baseClassLexerStringId]);
	}
	{
		auto it = compile.funcMap.find(name);
		if (it != compile.funcMap.end()) {
			return;
		}
	}

	auto &allCreateFuncNode = it->second;

	for (auto createFuncNode : allCreateFuncNode) {
		FunctionId funcId = createFuncNode->id;
		auto func = compile.functions[funcId];
		auto funcInfo = context.functionInfo[funcId];
		if (!funcInfo->genericData) {
			classDeclaration->throwError(func->getName(compile) +
			                             " is not generic");
		}
		if (classDeclaration->inputClassId.size() !=
		    funcInfo->genericData->genericDeclarations.size()) {
			continue;
		}
		auto allCreateFuncNode =
		    context
		        .genericFunctionMap[classDeclaration->baseClassLexerStringId];

		ParserContext::mode = createFuncNode->mode;

		std::vector<ClassDeclaration *> genericTypeId;
		genericTypeId.reserve(
		    funcInfo->genericData->genericDeclarations.size());

		for (size_t i = 0;
		     i < funcInfo->genericData->genericDeclarations.size(); ++i) {
			auto &genericDeclaration =
			    funcInfo->genericData->genericDeclarations[i];
			auto &inputClass = classDeclaration->inputClassId[i];

			ClassId inputClassId = *inputClass->classId;

			// Change callnode name
			if (!genericDeclaration->allCallNodes.empty()) {
				const std::string &name =
				    compile.classes[inputClassId]->getName(compile);
				auto nameId = context.createLexerStringIfNotExists(name);
				for (auto *callNode : genericDeclaration->allCallNodes) {
					callNode->nameId = nameId;
				}
			}
			// Change generics type
			genericDeclaration->classId = inputClassId;
			genericDeclaration->nullable = inputClass->nullable;
			ClassDeclaration *newClassDeclaration;
			if (inputClass->isGeneric) {
				newClassDeclaration = context.classDeclarationAllocator.push();
				newClassDeclaration->classId = inputClassId;
				newClassDeclaration->nullable = inputClass->nullable;
				newClassDeclaration->line = genericDeclaration->line;
				if (inputClassId == DefaultClass::functionClassId) {
					newClassDeclaration->inputClassId.reserve(
					    inputClass->inputClassId.size());
					for (auto classDeclaration : inputClass->inputClassId) {
						newClassDeclaration->inputClassId.push_back(
						    classDeclaration->copy(in_data));
					}
				}
			} else {
				newClassDeclaration = inputClass;
			}

			genericTypeId.push_back(newClassDeclaration);

			if (genericDeclaration->condition) {
				auto &condition = *genericDeclaration->condition;
				// if (condition.condition ==
				// GenericDeclarationCondition::MUST_EXTENDS) {
				if (!condition.classDeclaration->classId) {
					condition.classDeclaration->load<true>(in_data);
					if (!condition.classDeclaration->classId) {
						condition.classDeclaration->throwError(
						    "Unresolved " +
						    condition.classDeclaration->getName(in_data));
					}
				} else if (condition.classDeclaration->classId ==
				           DefaultClass::functionClassId) {
					condition.classDeclaration->load<true>(in_data);
				}
				context.checkValidateExtends[genericDeclaration].push_back(
				    newClassDeclaration);
				// }
			}

			for (auto *classDeclaration :
			     genericDeclaration->allClassDeclarations) {
				classDeclaration->classId = inputClassId;
				if (classDeclaration->mustInference) {
					classDeclaration->nullable = inputClass->nullable;
					// classDeclaration->mustInference = false;
				}
				classDeclaration->inputClassId =
				    newClassDeclaration->inputClassId;
				classDeclaration->baseClassLexerStringId =
				    inputClass->baseClassLexerStringId;
			}
		}

		for (auto &[classDeclaration, node] :
		     funcInfo->genericData->mustRenameNodes) {
			if (!classDeclaration->classId) {
				classDeclaration->load<false, true>(in_data);
				// if (!classDeclaration->classId) {
				// 	classDeclaration->throwError(
				// 	    "Unsolved " + classDeclaration->getName(in_data));
				// }
			}
			auto name = classDeclaration->getName(in_data);
			// std::cerr << name << "\n";
			switch (node->kind) {
				case NodeType::UNKNOW: {
					auto unknowNode = static_cast<UnknowNode *>(node);
					auto it = context.lexerStringMap.find(name);
					if (it == context.lexerStringMap.end()) {
						classDeclaration->throwError("Unsolved " + name);
					}
					unknowNode->nameId = it->second;
					break;
				}
				case NodeType::CALL: {
					auto callNode = static_cast<CallNode *>(node);
					auto it = context.lexerStringMap.find(name);
					if (it == context.lexerStringMap.end()) {
						classDeclaration->throwError("Unsolved " + name);
					}
					callNode->nameId = it->second;
					break;
				}
				default:
					break;
			}
			classDeclaration->classId = std::nullopt;
		}

		auto functionFlags =
		    createFuncNode->functionFlags & ~(FunctionFlags::FUNC_SKIP_LOAD);
		auto lastCurrentFunctionId = context.currentFunctionId;
		auto newCreateFuncNode = context.newFunctions.push(
		    createFuncNode->line, createFuncNode->tokenIndex,
		    createFuncNode->contextCallClassId,
		    context.createLexerStringIfNotExists(name), nullptr,
		    funcInfo->parameter->copy(in_data), functionFlags);

		if (createFuncNode->functionFlags & FunctionFlags::FUNC_IS_NATIVE) {
			newCreateFuncNode->pushNativeFunction(
			    in_data, compile.functions[createFuncNode->id]->native);
		} else {
			newCreateFuncNode->pushFunction(in_data);
		}
		auto newFunc = compile.functions[newCreateFuncNode->id];
		auto newFuncInfo = context.functionInfo[newCreateFuncNode->id];
		newFunc->maxDeclaration = func->maxDeclaration;
		newFuncInfo->declaration = funcInfo->declaration;
		newFunc->returnId = compile.functions[funcId]->returnId;
		context.gotoFunction(newCreateFuncNode->id);
		// std::cerr << "FUNC " << newFunc->getName(compile) << "\n";
		if (createFuncNode->classDeclaration) {
			if (!createFuncNode->classDeclaration->classId) {
				createFuncNode->classDeclaration->load<false>(in_data);
				if (!createFuncNode->classDeclaration->classId) {
					classDeclaration->throwError(
					    "Bug: Cannot resolve return type of generic function");
				}
				newFunc->returnId = *createFuncNode->classDeclaration->classId;
				createFuncNode->classDeclaration->classId = std::nullopt;
			} else {
				newFunc->returnId = *createFuncNode->classDeclaration->classId;
			}
			if (newFunc->returnId == DefaultClass::functionClassId) {
				newFuncInfo->returnClass =
				    createFuncNode->classDeclaration->copy(in_data);
			}
		}

		newFuncInfo->reflectDeclarationMap.reserve(
		    funcInfo->reflectDeclarationMap.size());

		for (auto &[declarationNode, value] : funcInfo->reflectDeclarationMap) {
			newFuncInfo->reflectDeclarationMap[declarationNode] =
			    static_cast<DeclarationNode *>(declarationNode->copy(in_data));
			// std::cerr << "Created declaration: " << declarationNode << " "
			//           << newFuncInfo->reflectDeclarationMap[declarationNode]
			//           << "\n";
		}

		for (auto &[declarationNode, value] :
		     funcInfo->genericData->staticDeclaration) {
			auto node = context.makeDeclarationNode(
			    in_data, declarationNode->line, declarationNode->baseName,
			    newFunc->getName(compile) +
			        context.lexerString[declarationNode->baseName],
			    declarationNode->classDeclaration, declarationNode->isVal, true,
			    declarationNode->nullable, false, true);
			funcInfo->genericData
			    ->newPositionOfStaticDeclaration[declarationNode->id] =
			    node->id;
			if (node->classDeclaration) {
				if (!node->classDeclaration->classId) {
					node->classDeclaration->load<false>(in_data);
					if (!node->classDeclaration->classId) {
						classDeclaration->throwError(
						    "Bug: Cannot find class name " +
						    node->classDeclaration->getName(in_data));
					}
					// std::cerr << "loaded "
					//           <<
					//           declarationNode->classDeclaration->getName(in_data)
					//           << "\n";
					node->optimize(in_data);
					node->classDeclaration->classId = std::nullopt;
				} else {
					node->classId = *node->classDeclaration->classId;
				}
			}
			node->optimize(in_data);
			if (value) {
				auto varNode = context.varPool.push(declarationNode->line, node,
				                                    false, true);
				auto setNode = context.setValuePool.push(declarationNode->line,
				                                         varNode, value, true);
				context.staticNode.push_back(setNode);
			}
			// declarationNode->classDeclaration = nullptr;
		}

		// ParserContext::mode = createFuncNode->mode; //Loaded in new class
		auto lastNewPositionOfStaticDeclaration =
		    context.newPositionOfStaticDeclaration;
		context.newPositionOfStaticDeclaration =
		    &funcInfo->genericData->newPositionOfStaticDeclaration;
		newFuncInfo->body.nodes.reserve(funcInfo->body.nodes.size());
		for (auto *node : funcInfo->body.nodes) {
			newFuncInfo->body.nodes.push_back(node->copy(in_data));
		}
		if (funcInfo->inferenceNode) {
			newFuncInfo->inferenceNode =
			    static_cast<ReturnNode *>(newFuncInfo->body.nodes[0]);
			context.mustInferenceFunctionType.push_back(newFunc->id);
		}
		context.newPositionOfStaticDeclaration =
		    lastNewPositionOfStaticDeclaration;
		context.gotoFunction(lastCurrentFunctionId);

		// for (auto &[classDeclaration, node] :
		//      funcInfo->genericData->mustRenameNodes) {
		// 	if (!classDeclaration) {
		// 		classDeclaration->load<false>(in_data);
		// 		if (!classDeclaration->classId) {
		// 			classDeclaration->throwError(
		// 			    "Unsolved " + classDeclaration->getName(in_data));
		// 		}
		// 	}
		// 	switch (node->kind) {
		// 		case NodeType::UNKNOW: {
		// 			auto unknowNode = static_cast<UnknowNode *>(node);
		// 			auto it = context.lexerStringMap.find(
		// 			    classDeclaration->getName(in_data));
		// 			if (it == context.lexerStringMap.end()) {
		// 				classDeclaration->throwError(
		// 				    "Unsolved " + classDeclaration->getName(in_data));
		// 			}
		// 			unknowNode->nameId = it->second;
		// 			break;
		// 		}
		// 		case NodeType::CALL: {
		// 			auto callNode = static_cast<CallNode *>(node);
		// 			auto it = context.lexerStringMap.find(
		// 			    classDeclaration->getName(in_data));
		// 			if (it == context.lexerStringMap.end()) {
		// 				classDeclaration->throwError(
		// 				    "Unsolved " + classDeclaration->getName(in_data));
		// 			}
		// 			callNode->nameId = it->second;
		// 			break;
		// 		}
		// 	}
		// 	classDeclaration->classId = std::nullopt;
		// }
	}
}

} // namespace AutoLang
#endif