#ifndef PARSER_CONTEXT_CPP
#define PARSER_CONTEXT_CPP

#include "frontend/parser/ParserContext.hpp"
#include "frontend/ACompiler.hpp"
#include "frontend/parser/Debugger.hpp"

namespace AutoLang {

LibraryData *ParserContext::mode = nullptr;

void ParserContext::init(CompiledProgram &compile) {
	static ConstValueNode constValues[3] = {
	    ConstValueNode(0, DefaultClass::nullObject, 0),
	    ConstValueNode(0, DefaultClass::trueObject, 1),
	    ConstValueNode(0, DefaultClass::falseObject, 2)};
	gotoFunction(compile.mainFunctionId);
	mainFunctionId = compile.mainFunctionId;

	lexerString.emplace_back("super");
	lexerString.emplace_back("Int");
	lexerString.emplace_back("Float");
	lexerString.emplace_back("Bool");
	lexerString.emplace_back("Null");
	lexerString.emplace_back("Void");
	lexerString.emplace_back("null");
	lexerString.emplace_back("true");
	lexerString.emplace_back("false");
	lexerString.emplace_back("__FILE__");
	lexerString.emplace_back("__LINE__");
	lexerString.emplace_back("__FUNC__");
	lexerString.emplace_back("__CLASS__");
	lexerString.emplace_back("getClassId");
	lexerString.emplace_back("Array");
	lexerString.emplace_back("Set");
	lexerString.emplace_back("Map");
	lexerString.emplace_back("[]");
	lexerString.emplace_back("get");
	lexerString.emplace_back("set");
	lexerString.emplace_back("contains");
	lexerString.emplace_back("this");
	lexerString.emplace_back("Function");
	lexerString.emplace_back("toString");

	lexerStringMap["super"] = lexerIdsuper;
	lexerStringMap["Int"] = lexerIdInt;
	lexerStringMap["Float"] = lexerIdFloat;
	lexerStringMap["Bool"] = lexerIdBool;
	lexerStringMap["Null"] = lexerIdNull;
	lexerStringMap["Void"] = lexerIdVoid;
	lexerStringMap["Function"] = lexerIdFunction;
	lexerStringMap["null"] = lexerIdnull;
	lexerStringMap["true"] = lexerIdtrue;
	lexerStringMap["false"] = lexerIdfalse;
	lexerStringMap["__FILE__"] = lexerId__FILE__;
	lexerStringMap["__LINE__"] = lexerId__LINE__;
	lexerStringMap["__FUNC__"] = lexerId__FUNC__;
	lexerStringMap["__CLASS__"] = lexerId__CLASS__;
	lexerStringMap["getClassId"] = lexerIdgetClassId;
	lexerStringMap["Array"] = lexerIdArray;
	lexerStringMap["Set"] = lexerIdSet;
	lexerStringMap["Map"] = lexerIdMap;
	lexerStringMap["[]"] = lexerIdLRBRACKET;
	lexerStringMap["get"] = lexerIdget;
	lexerStringMap["set"] = lexerIdset;
	lexerStringMap["contains"] = lexerIdcontains;
	lexerStringMap["this"] = lexerIdthis;
	lexerStringMap["toString"] = lexerIdtoString;

	constValue[lexerIdnull] = &constValues[0];
	constValue[lexerIdtrue] = &constValues[1];
	constValue[lexerIdfalse] = &constValues[2];

	annotationMetadata.reserve(4);
	closureScopes.reserve(4);

	{
		using namespace AutoLang::DefaultClass;
		using TT = AutoLang::Lexer::TokenType;
		binaryOpResultType = {
		    // int, float, bool
		    {makeTuple(intClassId, intClassId, (uint8_t)TT::PLUS), intClassId},
		    {makeTuple(intClassId, intClassId, (uint8_t)TT::MINUS), intClassId},
		    {makeTuple(intClassId, intClassId, (uint8_t)TT::STAR), intClassId},
		    {makeTuple(intClassId, intClassId, (uint8_t)TT::SLASH), intClassId},
		    {makeTuple(intClassId, intClassId, (uint8_t)TT::PERCENT),
		     intClassId},
		    {makeTuple(intClassId, intClassId, (uint8_t)TT::AND), intClassId},
		    {makeTuple(intClassId, intClassId, (uint8_t)TT::OR), intClassId},
		    {makeTuple(intClassId, intClassId, (uint8_t)TT::LT), boolClassId},
		    {makeTuple(intClassId, intClassId, (uint8_t)TT::GT), boolClassId},
		    {makeTuple(intClassId, intClassId, (uint8_t)TT::LTE), boolClassId},
		    {makeTuple(intClassId, intClassId, (uint8_t)TT::GTE), boolClassId},
		    {makeTuple(intClassId, intClassId, (uint8_t)TT::EQEQ), boolClassId},
		    {makeTuple(intClassId, intClassId, (uint8_t)TT::NOTEQ),
		     boolClassId},

		    {makeTuple(floatClassId, intClassId, (uint8_t)TT::PLUS),
		     floatClassId},
		    {makeTuple(floatClassId, intClassId, (uint8_t)TT::MINUS),
		     floatClassId},
		    {makeTuple(floatClassId, intClassId, (uint8_t)TT::STAR),
		     floatClassId},
		    {makeTuple(floatClassId, intClassId, (uint8_t)TT::SLASH),
		     floatClassId},
		    {makeTuple(floatClassId, intClassId, (uint8_t)TT::PERCENT),
		     floatClassId},
		    {makeTuple(floatClassId, intClassId, (uint8_t)TT::LT), boolClassId},
		    {makeTuple(floatClassId, intClassId, (uint8_t)TT::GT), boolClassId},
		    {makeTuple(floatClassId, intClassId, (uint8_t)TT::LTE),
		     boolClassId},
		    {makeTuple(floatClassId, intClassId, (uint8_t)TT::GTE),
		     boolClassId},
		    {makeTuple(floatClassId, intClassId, (uint8_t)TT::EQEQ),
		     boolClassId},
		    {makeTuple(floatClassId, intClassId, (uint8_t)TT::NOTEQ),
		     boolClassId},

		    {makeTuple(floatClassId, floatClassId, (uint8_t)TT::PLUS),
		     floatClassId},
		    {makeTuple(floatClassId, floatClassId, (uint8_t)TT::MINUS),
		     floatClassId},
		    {makeTuple(floatClassId, floatClassId, (uint8_t)TT::STAR),
		     floatClassId},
		    {makeTuple(floatClassId, floatClassId, (uint8_t)TT::SLASH),
		     floatClassId},
		    {makeTuple(floatClassId, floatClassId, (uint8_t)TT::PERCENT),
		     floatClassId},
		    {makeTuple(floatClassId, floatClassId, (uint8_t)TT::LT),
		     boolClassId},
		    {makeTuple(floatClassId, floatClassId, (uint8_t)TT::GT),
		     boolClassId},
		    {makeTuple(floatClassId, floatClassId, (uint8_t)TT::LTE),
		     boolClassId},
		    {makeTuple(floatClassId, floatClassId, (uint8_t)TT::GTE),
		     boolClassId},
		    {makeTuple(floatClassId, floatClassId, (uint8_t)TT::EQEQ),
		     boolClassId},
		    {makeTuple(floatClassId, floatClassId, (uint8_t)TT::NOTEQ),
		     boolClassId},

		    {makeTuple(boolClassId, intClassId, (uint8_t)TT::PLUS), intClassId},
		    {makeTuple(boolClassId, intClassId, (uint8_t)TT::MINUS),
		     intClassId},
		    {makeTuple(boolClassId, intClassId, (uint8_t)TT::STAR), intClassId},
		    {makeTuple(boolClassId, intClassId, (uint8_t)TT::SLASH),
		     intClassId},
		    {makeTuple(boolClassId, intClassId, (uint8_t)TT::PERCENT),
		     intClassId},

		    {makeTuple(boolClassId, floatClassId, (uint8_t)TT::PLUS),
		     floatClassId},
		    {makeTuple(boolClassId, floatClassId, (uint8_t)TT::MINUS),
		     floatClassId},
		    {makeTuple(boolClassId, floatClassId, (uint8_t)TT::STAR),
		     floatClassId},
		    {makeTuple(boolClassId, floatClassId, (uint8_t)TT::SLASH),
		     floatClassId},
		    {makeTuple(boolClassId, floatClassId, (uint8_t)TT::PERCENT),
		     floatClassId},

		    // string + int/float
		    {makeTuple(stringClassId, intClassId, (uint8_t)TT::PLUS),
		     stringClassId},
		    {makeTuple(stringClassId, floatClassId, (uint8_t)TT::PLUS),
		     stringClassId},
		    {makeTuple(stringClassId, stringClassId, (uint8_t)TT::PLUS),
		     stringClassId},

		    {makeTuple(stringClassId, stringClassId, (uint8_t)TT::EQEQ),
		     boolClassId},
		    {makeTuple(stringClassId, stringClassId, (uint8_t)TT::NOTEQ),
		     boolClassId},

		    {makeTuple(boolClassId, boolClassId, (uint8_t)TT::PLUS),
		     intClassId},
		    {makeTuple(boolClassId, boolClassId, (uint8_t)TT::MINUS),
		     intClassId},
		    {makeTuple(boolClassId, boolClassId, (uint8_t)TT::STAR),
		     intClassId},
		    {makeTuple(boolClassId, boolClassId, (uint8_t)TT::SLASH),
		     intClassId},
		    {makeTuple(boolClassId, boolClassId, (uint8_t)TT::AND_AND),
		     boolClassId},
		    {makeTuple(boolClassId, boolClassId, (uint8_t)TT::OR_OR),
		     boolClassId},
		    {makeTuple(boolClassId, boolClassId, (uint8_t)TT::EQEQ),
		     boolClassId},
		    {makeTuple(boolClassId, boolClassId, (uint8_t)TT::NOTEQ),
		     boolClassId},

		};
	}

	operatorTable = {{Lexer::TokenType::PLUS, OP_PLUS},
	                 {Lexer::TokenType::MINUS, OP_MINUS},
	                 {Lexer::TokenType::STAR, OP_MUL},
	                 {Lexer::TokenType::SLASH, OP_DIV},
	                 {Lexer::TokenType::PERCENT, OP_MOD},

	                 {Lexer::TokenType::PLUS_EQUAL, OP_PLUS_EQ},
	                 {Lexer::TokenType::MINUS_EQUAL, OP_MINUS_EQ},
	                 {Lexer::TokenType::STAR_EQUAL, OP_MUL_EQ},
	                 {Lexer::TokenType::SLASH_EQUAL, OP_DIV_EQ},
	                 //  {Lexer::TokenType::PERCENT_EQUAL, OP_MOD_EQ},

	                 {Lexer::TokenType::AND, OP_BIT_AND},
	                 {Lexer::TokenType::OR, OP_BIT_OR},

	                 {Lexer::TokenType::AND_AND, OP_AND_AND},
	                 {Lexer::TokenType::OR_OR, OP_OR_OR},

	                 {Lexer::TokenType::NOTEQEQ, OP_NOT_EQ_POINTER},
	                 {Lexer::TokenType::EQEQEQ, OP_EQ_POINTER},

	                 {Lexer::TokenType::NOTEQ, OP_NOT_EQ},
	                 {Lexer::TokenType::EQEQ, OP_EQEQ},

	                 {Lexer::TokenType::LT, OP_LESS},
	                 {Lexer::TokenType::GT, OP_GREATER},
	                 {Lexer::TokenType::GTE, OP_GREATER_EQ},
	                 {Lexer::TokenType::LTE, OP_LESS_EQ}};
}

void ParserContext::refresh(CompiledProgram &compile) {
	gotoFunction(compile.mainFunctionId);
	mainFunctionId = compile.mainFunctionId;

	loadingLibs.clear();
	tokens.clear();
	importMap.clear();

	for (auto &funcInfo : functionInfo) {
		funcInfo->body.refresh();
	}

	for (auto *node : staticNode) {
		ExprNode::deleteNode(node);
	}
	staticNode.clear();
	allClassDeclarations.clear();

	mustInferenceFunctionType.clear();

	newFunctions.refresh();
	newClasses.refresh();
	newDefaultClassesMap.clear();
	newGenericClassesMap.clear();

	hasError = false;
	canBreakContinue = false;
	justFindStatic = false;
	isInGeneric = false;

	closureCount = 0;
	continuePos = 0;
	breakPos = 0;
	jumpIfNullNode = nullptr;
	mustReturnValueNode = nullptr;
	newPositionOfStaticDeclaration = nullptr;
	preloadGenericData = nullptr;

	defaultValueParameter.clear();

	parameterPool.destroy();
	functionInfoAllocator.destroy();
	classInfoAllocator.destroy();
	functionInfo.clear();
	globalFunction.clear();
	genericFunctionMap.clear();
	defaultClassMap.clear();
	classInfo.clear();

	createConstructorPool.destroy();
	ifPool.destroy();
	whilePool.destroy();
	tryCatchPool.destroy();
	skipNodePool.destroy();
	closureScopes.clear();
	genericDataPool.destroy();

	declarationNodePool.refresh();
	returnPool.destroy();
	setValuePool.destroy();

	throwPool.destroy();
	binaryNodePool.destroy();
	castPool.destroy();
	runtimeCastPool.destroy();
	varPool.destroy();
	getPropPool.destroy();
	unknowNodePool.destroy();
	optionalAccessNodePool.destroy();
	nullCoalescingPool.destroy();
	blockNodePool.destroy();
	callNodePool.destroy();
	classAccessPool.destroy();
	constValuePool.destroy();
	unaryNodePool.destroy();
	forPool.destroy();
	rangeNode.destroy();
	createArrayPool.destroy();
	createClosurePool.destroy();
	createSetPool.destroy();
	createMapPool.destroy();
	whenNodePool.destroy();
	functionAccessPool.destroy();
	classDeclarationAllocator.destroy();
	genericCallers.clear();
	checkValidateExtends.clear();
	allClosureNode.clear();

	currentClassId = std::nullopt;

	constIntMap.clear();
	constFloatMap.clear();
	for (auto [str, _] : constStringMap) {
		delete str;
	}
	constStringMap.clear();
	lexerString = stdLexerString;
	lexerStringMap = stdLexerStringMap;
}

void ParserContext::logError(uint32_t line, const std::string &message) {
	if (onError) {
		std::string mes =
		    mode->path + ":" + std::to_string(line) + ": " + message;
		(*onError)(mes);
		return;
	}
	std::cerr << mode->path << ":" << line << ": " << message << std::endl;
}

void ParserContext::warning(uint32_t line, const std::string &message) {
	if (onWarning) {
		std::string mes =
		    mode->path + ":" + std::to_string(line) + ": " + message;
		(*onWarning)(mes);
		return;
	}
	std::cerr << mode->path << ":" << line << ": Warning " << message
	          << std::endl;
}

HasClassIdNode *ParserContext::findDeclaration(in_func, uint32_t line,
                                               LexerStringId nameId,
                                               bool inGlobal) {
	const auto &name = context.lexerString[nameId];
	if (context.currentClosureNode) {
		for (int i = context.closureScopes.size(); i-- > 0;) {
			auto closure = context.closureScopes[i];
			auto node = closure->scopes.findDeclaration(in_data, line, nameId,
			                                            justFindStatic);
			if (!node) {
				continue;
			}

			for (int j = i + 1; j < context.closureScopes.size(); ++j) {
				auto closure_ = context.closureScopes[j];
				closure_->parameter->parameters.insert(
				    closure_->parameter->parameters.begin(), node->declaration);
				closure_->scopes[0][nameId] = node->declaration;
				closure_->objects.insert(closure_->objects.begin(), node);
			}
			return node;
		}
	}
	if (currentFunctionId != mainFunctionId) {
		auto funcInfo = getCurrentFunctionInfo(in_data);
		AccessNode *node =
		    funcInfo->findDeclaration(in_data, line, nameId, justFindStatic);
		if (node) {
			if (context.currentClosureNode && !node->declaration->isGlobal) {
				// if (node->declaration->isGlobal) {
				// std::cerr << context.lexerString[nameId] << "\n";
				// }
				for (auto closure : context.closureScopes) {
					closure->parameter->parameters.insert(
					    closure->parameter->parameters.begin(),
					    node->declaration);
					closure->scopes[0][nameId] = node->declaration;
					closure->objects.insert(closure->objects.begin(), node);
				}
				return node;
			}
			return node;
		}
	}
	if (!inGlobal) {
		return nullptr;
	}
	auto node =
	    getMainFunctionInfo(in_data)->findDeclaration(in_data, line, nameId);
	if (node == nullptr)
		return nullptr;
	if (justFindStatic)
		goto isNotStatic;
	// if (currentClassId) {
	// 	auto func = getCurrentFunction(in_data);
	// 	node = getCurrentClassInfo(in_data)->findDeclaration(
	// 	    in_data, line, nameId, justFindStatic);
	// 	// Static in function is VarNode, NonStatic is GetPropNode
	// 	if ((func->functionFlags & FunctionFlags::FUNC_IS_STATIC) && node &&
	// 	    node->kind == NodeType::GET_PROP)
	// 		goto isNotStatic;
	// 	if (node)
	// 		return node;
	// }

	return node;
isNotStatic:;
	throw ParserError(line, name + " is not static");
}

DeclarationNode *ParserContext::makeDeclarationNode(
    in_func, uint32_t line, LexerStringId baseName, const std::string &name,
    ClassDeclaration *classDeclaration, bool isVal, bool isGlobal,
    bool nullable, bool addToScope, bool loadId) {
	if (context.currentClosureNode) {
		if (isGlobal) {
			throw ParserError(
			    line, "Error: Static declarations are not allowed inside "
			          "closures\nNote: Move the declaration to an outer scope");
		}
		if (addToScope) {
			auto &scope = context.currentClosureNode->scopes.back();
			auto it = scope.find(baseName);
			if (it != scope.end()) {
				throw ParserError(line, "Redefinition of variable '" +
				                            context.lexerString[baseName] +
				                            "'. Previous definition here: " +
				                            it->second->mode->path + ":" +
				                            std::to_string(it->second->line) +
				                            "");
			}
		}
		DeclarationNode *node = declarationNodePool.push(
		    line, context.currentClassId, baseName, name, classDeclaration,
		    isVal, isGlobal, nullable);
		context.currentClosureNode->newDeclaration.push_back(node);
		node->classId = AutoLang::DefaultClass::nullClassId;
		node->id = loadId ? context.currentClosureNode->declarationCount++ : 0;
		if (context.currentClassId) {
			auto classInfo = context.classInfo[*context.currentClassId];
			classInfo->allDeclarationNode.push_back(node);
		}
		// funcInfo->declarationNodes.push_back(node);
		if (loadId) {
			size_t newSize = context.currentClosureNode->declarationCount;
			if (newSize > context.currentClosureNode->maxDeclaration)
				context.currentClosureNode->maxDeclaration = newSize;
			if (addToScope) {
				auto &scope = context.currentClosureNode->scopes.back();
				scope[node->baseName] = node;
			}
		}
		return node;
	}
	auto func =
	    isGlobal ? getMainFunction(in_data) : getCurrentFunction(in_data);
	auto funcInfo = isGlobal ? getMainFunctionInfo(in_data)
	                         : getCurrentFunctionInfo(in_data);
	if (addToScope) {
		auto &scope = funcInfo->scopes.back();
		auto it = scope.find(baseName);
		if (it != scope.end()) {
			throw ParserError(
			    line,
			    "Redefinition of variable '" + context.lexerString[baseName] +
			        "'. Previous definition here: " + it->second->mode->path +
			        ":" + std::to_string(it->second->line) + "");
		}
	}
	DeclarationNode *node =
	    declarationNodePool.push(line, context.currentClassId, baseName, name,
	                             classDeclaration, isVal, isGlobal, nullable);
	node->classId = AutoLang::DefaultClass::nullClassId;
	node->id = loadId ? funcInfo->declaration++ : 0;
	if (context.currentClassId) {
		auto classInfo = context.classInfo[*context.currentClassId];
		classInfo->allDeclarationNode.push_back(node);
	}
	// funcInfo->declarationNodes.push_back(node);
	if (loadId) {
		size_t newSize = funcInfo->declaration;
		if (newSize > func->maxDeclaration)
			func->maxDeclaration = newSize;
		if (addToScope) {
			auto &scope = funcInfo->scopes.back();
			scope[node->baseName] = node;
		}
	}
	return node;
}

ParserContext::~ParserContext() {
	if (onError) {
		delete onError;
	}
	if (onWarning) {
		delete onWarning;
	}
	// for (auto* node : staticNode) { //Deleted
	// 	ExprNode::deleteNode(node);
	// }
}

} // namespace AutoLang

#endif