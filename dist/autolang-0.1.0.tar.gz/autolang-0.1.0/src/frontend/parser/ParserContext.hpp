#ifndef PARSER_CONTEXT_HPP
#define PARSER_CONTEXT_HPP

#include "backend/vm/AVM.hpp"
#include "frontend/parser/ClassDeclaration.hpp"
#include "frontend/parser/ClassInfo.hpp"
#include "frontend/parser/FunctionEvent.hpp"
#include "frontend/parser/FunctionInfo.hpp"
#include "frontend/parser/OperatorId.hpp"
#include "frontend/parser/node/CreateFuncNode.hpp"
#include "frontend/parser/node/CreateNode.hpp"
#include "frontend/structure/NonReallocatePool.hpp"
#include "shared/ChunkArena.hpp"
#include "shared/ClassFlags.hpp"
#include <set>
#include <vector>

namespace AutoLang {

enum ModifierFlags : uint32_t {
	MF_PUBLIC = 1u << 0,
	MF_PRIVATE = 1u << 1,
	MF_PROTECTED = 1u << 2,
	MF_STATIC = 1u << 3,
	MF_LATEINIT = 1u << 4,
};

enum AnnotationFlags : uint32_t {
	AN_OVERRIDE = 1u << 0,
	AN_NO_OVERRIDE = 1u << 1,
	AN_NATIVE = 1u << 2,
	AN_NO_CONSTRUCTOR = 1u << 3,
	AN_WAIT_INPUT = 1u << 4,
	AN_NO_EXTENDS = 1u << 5,
	AN_NATIVE_DATA = 1u << 6,
#ifdef __EMSCRIPTEN__
	AN_JS_OBJECT = 1u << 7,
#elif __PYBIND11__
	AN_PY_OBJECT = 1u << 7,
#endif
};

struct LibraryData;

constexpr LexerStringId lexerIdsuper = 0;
constexpr LexerStringId lexerIdInt = 1;
constexpr LexerStringId lexerIdFloat = 2;
constexpr LexerStringId lexerIdBool = 3;
constexpr LexerStringId lexerIdNull = 4;
constexpr LexerStringId lexerIdVoid = 5;
constexpr LexerStringId lexerIdnull = 6;
constexpr LexerStringId lexerIdtrue = 7;
constexpr LexerStringId lexerIdfalse = 8;
constexpr LexerStringId lexerId__FILE__ = 9;
constexpr LexerStringId lexerId__LINE__ = 10;
constexpr LexerStringId lexerId__FUNC__ = 11;
constexpr LexerStringId lexerId__CLASS__ = 12;
constexpr LexerStringId lexerIdgetClassId = 13;
constexpr LexerStringId lexerIdArray = 14;
constexpr LexerStringId lexerIdSet = 15;
constexpr LexerStringId lexerIdMap = 16;
constexpr LexerStringId lexerIdLRBRACKET = 17;
constexpr LexerStringId lexerIdget = 18;
constexpr LexerStringId lexerIdset = 19;
constexpr LexerStringId lexerIdcontains = 20;
constexpr LexerStringId lexerIdthis = 21;
constexpr LexerStringId lexerIdFunction = 22;
constexpr LexerStringId lexerIdtoString = 23;

using GenericCaller = ClassDeclaration;

struct ParserContext {
	FunctionEvent *onError = nullptr;
	FunctionEvent *onWarning = nullptr;
	// Optimize ram because reuse std::string instead of new std::string in
	// lexer
	std::vector<std::string> lexerString;
	HashMap<std::string, LexerStringId> lexerStringMap;

	std::vector<std::string> stdLexerString;
	HashMap<std::string, LexerStringId> stdLexerStringMap;

	Lexer::Context *mainLexerContext;
	HashMap<std::string, LibraryData *> importMap;
	std::vector<LibraryData *> loadingLibs;

	HashMap<Lexer::TokenType, OperatorId> operatorTable;

	HashMap<std::tuple<ClassId, ClassId, uint8_t>, ClassId, PairHash>
	    binaryOpResultType;
	// Parse file to tokens
	std::vector<Lexer::Token> tokens;
	// Keywords , example public, private, static
	uint32_t modifierflags = 0;
	// Anotations
	uint32_t annotationFlags = 0;
	uint32_t closureCount = 0;
	HashMap<AnnotationFlags, Lexer::Token> annotationMetadata;
	// Declaration new functions by users
	CreateClosureNode *currentClosureNode = nullptr;
	std::vector<CreateClosureNode *> closureScopes;
	NonReallocatePool<CreateFuncNode> newFunctions;
	HashMap<LexerStringId, std::vector<CreateFuncNode *>> genericFunctionMap;
	std::vector<FunctionId> mustInferenceFunctionType;
	HashMap<LexerStringId, std::vector<FunctionId>> globalFunction;
	// Find, example fun load<T>(a: T)
	GenericData *preloadGenericData = nullptr;
	ChunkArena<GenericData, 8> genericDataPool;
	HashMap<DeclarationOffset, DeclarationOffset>
	    *newPositionOfStaticDeclaration = nullptr;
	HashMap<GenericDeclarationNode *, std::vector<ClassDeclaration *>>
	    checkValidateExtends;
	// Declaration new classes by user
	NonReallocatePool<CreateClassNode> newClasses;
	HashMap<LexerStringId, ClassId> defaultClassMap;

	HashMap<uint32_t, CreateClassNode *> newDefaultClassesMap;
	HashMap<uint32_t, CreateClassNode *> newGenericClassesMap;
	ChunkArena<ClassDeclaration, 64> classDeclarationAllocator;
	std::vector<ClassDeclaration *> allClassDeclarations;

	bool hasError = false;
	bool canBreakContinue = false;
	// Be used when it is static keywords, example static val a = ...
	bool justFindStatic = false;
	bool justFindStaticMember = false;
	bool isInGeneric = false;
	// Be used when put bytecodes with break or continue
	uint32_t continuePos = 0;
	uint32_t breakPos = 0;
	uint32_t currentBytecodePos = 0;
	size_t currentTokenPos = 0;
	JumpIfNullNode *jumpIfNullNode = nullptr;
	HasClassIdNode *mustReturnValueNode = nullptr;

	std::vector<GenericCaller *> genericCallers;

	// Function information in compiler time
	ChunkArena<FunctionInfo, 64> functionInfoAllocator;
	std::vector<FunctionInfo *> functionInfo;
	// Class information in compiler time
	ChunkArena<ClassInfo, 64> classInfoAllocator;
	std::vector<ClassInfo *> classInfo;
	// All static variable will be here and put bytecodes to ".main" function
	std::vector<ExprNode *> staticNode;
	std::vector<Parameter *> defaultValueParameter;
	std::vector<CreateClosureNode *> allClosureNode;

	NonReallocatePool<DeclarationNode> declarationNodePool;
	ChunkArena<Parameter, 64> parameterPool;
	ChunkArena<ReturnNode, 64> returnPool;
	ChunkArena<SetNode, 128> setValuePool;
	ChunkArena<CreateConstructorNode, 32> createConstructorPool;
	ChunkArena<BinaryNode, 128> binaryNodePool;
	ChunkArena<IfNode, 128> ifPool;
	ChunkArena<WhileNode, 32> whilePool;
	ChunkArena<TryCatchNode, 16> tryCatchPool;
	ChunkArena<ThrowNode, 32> throwPool;
	ChunkArena<CastNode, 32> castPool;
	ChunkArena<RuntimeCastNode, 16> runtimeCastPool;
	ChunkArena<VarNode, 128> varPool;
	ChunkArena<GetPropNode, 128> getPropPool;
	ChunkArena<UnknowNode, 128> unknowNodePool;
	ChunkArena<OptionalAccessNode, 32> optionalAccessNodePool;
	ChunkArena<NullCoalescingNode, 32> nullCoalescingPool;
	ChunkArena<BlockNode, 64> blockNodePool;
	ChunkArena<CallNode, 64> callNodePool;
	// ChunkArena<CallNode, 16> callFuncObjectNodePool;
	ChunkArena<ClassAccessNode, 32> classAccessPool;
	ChunkArena<ConstValueNode, 128> constValuePool;
	ChunkArena<UnaryNode, 16> unaryNodePool;
	ChunkArena<SkipNode, 16> skipNodePool;
	ChunkArena<ForNode, 32> forPool;
	ChunkArena<RangeNode, 16> rangeNode;
	ChunkArena<CreateArrayNode, 32> createArrayPool;
	ChunkArena<CreateSetNode, 16> createSetPool;
	ChunkArena<CreateMapNode, 16> createMapPool;
	ChunkArena<WhenNode, 16> whenNodePool;
	ChunkArena<FunctionAccessNode, 8> functionAccessPool;
	ChunkArena<CreateClosureNode, 32> createClosurePool;
	// ChunkArena<GetPointerNode, 8> getPointerPool;

	std::optional<ClassId> currentClassId = std::nullopt;
	uint32_t mainFunctionId;
	uint32_t currentFunctionId;

	static LibraryData *mode;

	HashMap<int64_t, Offset> constIntMap;
	HashMap<double, Offset> constFloatMap;
	HashMap<AString *, Offset, AString::Hash, AString::Equal> constStringMap;

	// Constant value, example "null", "true", "false"
	HashMap<LexerStringId, ConstValueNode *> constValue;
	void init(CompiledProgram &compiler);
	void logError(uint32_t line, const std::string &message);
	void warning(uint32_t line, const std::string &message);
	void refresh(CompiledProgram &compile);
	inline static std::tuple<ClassId, ClassId, uint8_t>
	makeTuple(ClassId first, ClassId second, uint8_t op) {
		return std::make_tuple(std::min(first, second), std::max(first, second),
		                       op);
	}
	inline void addTypeResult(ClassId first, ClassId second, uint8_t op,
	                          ClassId classId) {
		binaryOpResultType[{std::min(first, second), std::max(first, second),
		                    op}] = classId;
	}

	inline bool getTypeResult(ClassId first, ClassId second, uint8_t op,
	                          ClassId &result) {
		auto it = binaryOpResultType.find(
		    {std::min(first, second), std::max(first, second), op});
		if (it == binaryOpResultType.end())
			return false;
		result = it->second;
		return true;
	}

	inline void gotoFunction(uint32_t currentFunctionId) {
		this->currentFunctionId = currentFunctionId;
	}
	inline void gotoClass(AClass *clazz) {
		if (clazz == nullptr) {
			currentClassId = std::nullopt;
			return;
		}
		currentClassId = clazz->id;
	}
	inline Function *getMainFunction(in_func) {
		return compile.functions[mainFunctionId];
	}
	inline FunctionInfo *getMainFunctionInfo(in_func) {
		return functionInfo[mainFunctionId];
	}
	inline Function *getCurrentFunction(in_func) {
		return compile.functions[currentFunctionId];
	}
	inline FunctionInfo *getCurrentFunctionInfo(in_func) {
		return functionInfo[currentFunctionId];
	}
	inline AClass *getCurrentClass(in_func) {
		return currentClassId ? compile.classes[*currentClassId] : nullptr;
	}
	inline ClassInfo *getCurrentClassInfo(in_func) {
		return currentClassId ? classInfo[*currentClassId] : nullptr;
	}
	std::string checkValidDeclarationName(LexerStringId nameId) {
		switch (nameId) {
			case lexerId__LINE__:
			case lexerId__FILE__:
			case lexerId__CLASS__:
			case lexerId__FUNC__: {
				return lexerString[nameId] + " is magic const value";
			}
		}
		return "";
	}
	static inline std::optional<uint32_t> getClassId(AClass *clazz) {
		if (!clazz)
			return std::nullopt;
		return clazz->id;
	}
	CreateClassNode *findCreateClassNode(uint32_t id) {
		{
			auto it = newDefaultClassesMap.find(id);
			if (it != newDefaultClassesMap.end()) {
				return it->second;
			}
		}
		{
			auto it = newGenericClassesMap.find(id);
			if (it != newGenericClassesMap.end()) {
				return it->second;
			}
		}
		return nullptr;
	}
	HasClassIdNode *findDeclaration(in_func, uint32_t line,
	                                LexerStringId nameId, bool inGlobal);
	DeclarationNode *makeDeclarationNode(
	    in_func, uint32_t line, LexerStringId baseName, const std::string &name,
	    ClassDeclaration *classDeclaration, bool isVal, bool isGlobal,
	    bool nullable, bool addToScope = true, bool loadId = true);
	inline size_t getBoolConstValuePosition(bool b) { return b ? 1 : 2; }
	inline LexerStringId createLexerStringIfNotExists(const std::string &str) {
		auto it = lexerStringMap.find(str);
		if (it != lexerStringMap.end()) {
			return it->second;
		}
		LexerStringId id = lexerString.size();
		lexerStringMap[str] = id;
		lexerString.push_back(str);
		return id;
	}
	~ParserContext();
};

} // namespace AutoLang

#endif