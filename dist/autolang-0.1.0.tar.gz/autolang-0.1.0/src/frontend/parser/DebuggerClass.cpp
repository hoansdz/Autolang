#ifndef DEBUGGER_CLASS_CPP
#define DEBUGGER_CLASS_CPP

#include "frontend/ACompiler.hpp"
#include "frontend/parser/Debugger.hpp"
#include "frontend/parser/ParserContext.hpp"
#include "shared/ClassFlags.hpp"
#include <memory>

namespace AutoLang {

CreateClassNode *loadClass(in_func, size_t &i) {
	ensureNoKeyword(in_data, i);
	Lexer::Token *token = &context.tokens[i];
	uint32_t firstLine = token->line;

	uint32_t classFlags = 0;
	if (context.annotationFlags & AnnotationFlags::AN_NATIVE) {
		throw ParserError(firstLine, "@native is only supported on functions");
	}
	if (context.annotationFlags & AnnotationFlags::AN_OVERRIDE) {
		throw ParserError(firstLine,
		                  "@override is only supported on functions");
	}
	if (context.annotationFlags & AnnotationFlags::AN_NO_OVERRIDE) {
		throw ParserError(firstLine,
		                  "@no_override is only supported on functions");
	}
	if (context.annotationFlags & AnnotationFlags::AN_NO_CONSTRUCTOR) {
		classFlags |= ClassFlags::CLASS_NO_CONSTRUCTOR;
	}
	if (context.annotationFlags & AnnotationFlags::AN_NO_EXTENDS) {
		classFlags |= ClassFlags::CLASS_NO_EXTENDS;
	}
	if (context.annotationFlags & AnnotationFlags::AN_NATIVE_DATA) {
		// classFlags |= ClassFlags::CLASS_NATIVE_DATA;
	}
#ifdef __EMSCRIPTEN__
	if (context.annotationFlags & AnnotationFlags::AN_JS_OBJECT) {
		classFlags |= ClassFlags::CLASS_JS_OBJECT;
	}
#elif __PYBIND11__
	if (context.annotationFlags & AnnotationFlags::AN_PY_OBJECT) {
		classFlags |= ClassFlags::CLASS_PY_OBJECT;
	}
#endif

	// Name
	if (!nextTokenSameLine(&token, context.tokens, i, firstLine) ||
	    !expect(token, Lexer::TokenType::IDENTIFIER)) {
		--i;
		throw ParserError(firstLine, "Expected name but not found");
	}
	LexerStringId nameId = token->indexData;
	const std::string &name = context.lexerString[nameId];

	if (context.defaultClassMap.find(nameId) != context.defaultClassMap.end()) {
		throw ParserError(firstLine, "Class " + name + " already exists");
	}

	auto node = context.newClasses.push(firstLine, nameId,
	                                    classFlags); // NewClasses managed
	node->pushClass(in_data);
	auto lastClass = context.getCurrentClass(in_data);
	auto clazz = compile.classes[node->classId];
	context.gotoClass(clazz);
	auto declarationThis = context.declarationNodePool.push(
	    firstLine, context.currentClassId, lexerIdthis, "this", nullptr, true,
	    false, false);
	declarationThis->classId = node->classId;
	//'this' is always input at first position
	declarationThis->id = 0;
	auto classInfo = context.getCurrentClassInfo(in_data);
	classInfo->declarationThis = declarationThis;

	try {

		if (!nextToken(&token, context.tokens, i)) {
			--i;
			context.newDefaultClassesMap[node->classId] = node;
			if (classFlags & ClassFlags::CLASS_NO_CONSTRUCTOR) {
				context.gotoClass(lastClass);
				return node;
			}
			auto parameter = context.parameterPool.push();
			parameter->defaultValuePos = 1;
			parameter->parameters =
			    std::vector<DeclarationNode *>{classInfo->declarationThis};
			auto *constructor = context.createConstructorPool.push(
			    firstLine, *context.currentClassId, nameId, parameter, false,
			    FunctionFlags::FUNC_PUBLIC);
			classInfo->secondaryConstructor.push_back(constructor);
			constructor->pushFunction(in_data);
			context.gotoClass(lastClass);
			return node;
		}
		if (expect(token, Lexer::TokenType::LT)) {
			classInfo->genericData = context.genericDataPool.push();
			context.newGenericClassesMap[node->classId] = node;
			while (true) {
				if (!nextToken(&token, context.tokens, i) ||
				    !expect(token, Lexer::TokenType::IDENTIFIER)) {
					--i;
					throw ParserError(context.tokens[i].line,
					                  "Expected class name but not found");
				}
				auto &genericDeclarationName =
				    context.lexerString[token->indexData];
				if (classInfo->findGenericDeclaration(token->indexData)) {
					throw ParserError(firstLine,
					                  "Redefined " + genericDeclarationName);
				}
				Offset id = classInfo->genericData->genericDeclarations.size();
				context.isInGeneric = true;
				auto declarationData =
				    new GenericDeclarationNode(firstLine, token->indexData);
				// declarationData->classDeclaration.baseClassLexerStringId =
				// nameId;
				// declarationData->classDeclaration.isGenericDeclaration =
				// true; declarationData->classDeclaration.line = token->line;
				classInfo->genericData->genericDeclarations.push_back(
				    declarationData);
				classInfo->genericData
				    ->genericDeclarationMap[token->indexData] = id;
				if (!nextToken(&token, context.tokens, i)) {
					--i;
					throw ParserError(
					    context.tokens[i].line,
					    "Expected '>' after class name but not found");
				}
				switch (token->type) {
					// case Lexer::TokenType::IS:
					case Lexer::TokenType::EXTENDS: {
						// auto condition =
						//     (token->type == Lexer::TokenType::EXTENDS)
						//         ? GenericDeclarationCondition::MUST_EXTENDS
						//         : GenericDeclarationCondition::MUST_IS;
						auto classDeclaration = loadClassDeclaration(
						    in_data, i, token->line, false);
						if (!nextToken(&token, context.tokens, i)) {
							throw ParserError(
							    firstLine,
							    "Expected '>' after class name but not found");
						}
						declarationData->condition =
						    GenericDeclarationCondition{classDeclaration};
						switch (token->type) {
							case Lexer::TokenType::COMMA: {
								break;
							}
							case Lexer::TokenType::GT: {
								goto finishedGenerics;
							}
							default: {
								throw ParserError(firstLine,
								                  "Expected '>' after class "
								                  "name but not found");
							}
						}
						break;
					}
					case Lexer::TokenType::COMMA: {
						break;
					}
					case Lexer::TokenType::GT: {
						goto finishedGenerics;
					}
					default: {
						throw ParserError(
						    firstLine,
						    "Expected '>' after class name but not found");
					}
				}
			}
		finishedGenerics:;
			if (!nextToken(&token, context.tokens, i)) {
				--i;
				throw ParserError(context.tokens[i].line,
				                  "Generics class must have body");
			}
		} else {
			context.newDefaultClassesMap[node->classId] = node;
		}

		if (expect(token, Lexer::TokenType::EXTENDS)) {
			node->superDeclaration =
			    loadClassDeclaration(in_data, i, token->line, false);
			if (!node->superDeclaration->isGenerics(in_data)) {
				context.allClassDeclarations.push_back(node->superDeclaration);
			}
			// auto name = node->superDeclaration->getName(in_data);
			// std::cerr << "Created extends: " << name << "\n";
			// LexerStringId newNameId;
			// {
			// 	auto it = context.lexerStringMap.find(name);
			// 	if (it == context.lexerStringMap.end()) {
			// 		newNameId = context.lexerString.size();
			// 		context.lexerStringMap[name] = newNameId;
			// 		context.lexerString.push_back(name);
			// 	} else {
			// 		newNameId = it->second;
			// 	}
			// }

			classFlags |= ClassFlags::CLASS_HAS_PARENT;
			clazz->classFlags |= ClassFlags::CLASS_HAS_PARENT;
			node->classFlags |= ClassFlags::CLASS_HAS_PARENT;
			if (!nextToken(&token, context.tokens, i)) {
				--i;
				throw ParserError(context.tokens[i].line,
				                  "Extended class must have constructor");
			}
		}
		// std::cerr<<"Clazz: "<<clazz->getName(compile)<<"
		// "<<declarationThis->id<<"\n"; Has PrimaryConstructor
		//  bool hasPrimaryConstructor = false;
		if (expect(token, Lexer::TokenType::LPAREN)) {
			if (classFlags & ClassFlags::CLASS_HAS_PARENT) {
				throw ParserError(
				    context.tokens[i].line,
				    "Extended classes don't support a primary (data class) "
				    "constructor; you must declare a constructor and call "
				    "super");
			}
			if (classFlags & ClassFlags::CLASS_NO_CONSTRUCTOR) {
				throw ParserError(
				    context.tokens[i].line,
				    "@no_constructor is already applied, cannot use "
				    "primary constructor");
			}
			if (classFlags & ClassFlags::CLASS_NATIVE_DATA) {
				throw ParserError(context.tokens[i].line,
				                  "@native_data is already applied");
			}
			auto parameters = loadListDeclaration(in_data, i, true);
			if (!parameters->parameterDefaultValues.empty() &&
			    !classInfo->genericData) {
				context.defaultValueParameter.push_back(parameters);
			}

			for (int i = 0; i < parameters->parameters.size(); ++i) {
				parameters->parameters[i]->id = i;
			}

			parameters->parameters.insert(parameters->parameters.begin(),
			                              classInfo->declarationThis);
			parameters->defaultValuePos += 1;
			classInfo->primaryConstructor = context.createConstructorPool.push(
			    firstLine, *context.currentClassId, nameId, parameters, true,
			    FunctionFlags::FUNC_PUBLIC);
			classInfo->primaryConstructor->pushFunction(in_data);
			if (!nextToken(&token, context.tokens, i)) {
				context.isInGeneric = false;
				context.gotoClass(lastClass);
				--i;
				return node;
			}
		}

		if (expect(token, Lexer::TokenType::LBRACE)) {
			loadBody<false>(in_data, node->body.nodes, i, false);
			// Create constructor if it hasn't constructor
			if (!(classFlags & ClassFlags::CLASS_NO_CONSTRUCTOR) &&
			    !classInfo->primaryConstructor &&
			    classInfo->secondaryConstructor.empty()) {
				if (classFlags & ClassFlags::CLASS_HAS_PARENT) {
					throw ParserError(
					    firstLine, "Extended class must declare a constructor");
				}
				auto parameter = context.parameterPool.push();
				parameter->defaultValuePos = 1;
				parameter->parameters =
				    std::vector<DeclarationNode *>{classInfo->declarationThis};
				auto *constructor = context.createConstructorPool.push(
				    firstLine, *context.currentClassId, nameId, parameter,
				    false, FunctionFlags::FUNC_PUBLIC);
				classInfo->secondaryConstructor.push_back(constructor);
				constructor->pushFunction(in_data);
			}

			context.gotoClass(lastClass);
		} else {
			// Create constructor if it hasn't constructor
			if (!(classFlags & ClassFlags::CLASS_NO_CONSTRUCTOR) &&
			    !classInfo->primaryConstructor &&
			    classInfo->secondaryConstructor.empty()) {
				if (classFlags & ClassFlags::CLASS_HAS_PARENT) {
					throw ParserError(
					    firstLine, "Extended class must declare a constructor");
				}

				auto parameter = context.parameterPool.push();
				parameter->defaultValuePos = 1;
				parameter->parameters =
				    std::vector<DeclarationNode *>{classInfo->declarationThis};
				classInfo->primaryConstructor =
				    context.createConstructorPool.push(
				        firstLine, *context.currentClassId, nameId, parameter,
				        true, FunctionFlags::FUNC_PUBLIC);
				classInfo->primaryConstructor->pushFunction(in_data);
			}

			context.gotoClass(lastClass);
			--i;
		}
		if (context.isInGeneric)
			context.isInGeneric = false;
		return node;
	} catch (const ParserError &err) {
		context.isInGeneric = false;
		context.gotoClass(lastClass);
		throw err;
	}
}

void loadConstructor(in_func, size_t &i) {
	Lexer::Token *token = &context.tokens[i];
	uint32_t firstLine = token->line;
	auto clazz = context.getCurrentClass(in_data);
	auto classInfo = context.getCurrentClassInfo(in_data);

	if (clazz->classFlags & ClassFlags::CLASS_NO_CONSTRUCTOR) {
		throw ParserError(firstLine, "@no_constructor is already applied");
	}
	if (classInfo->primaryConstructor)
		throw ParserError(firstLine,
		                  "Cannot declare constructor in a data class");
	uint32_t functionFlags = 0;
	Lexer::TokenType accessModifier = getAndEnsureOneAccessModifier(in_data, i);
	switch (accessModifier) {
		case Lexer::TokenType::PUBLIC: {
			functionFlags |= FunctionFlags::FUNC_PUBLIC;
			break;
		}
		case Lexer::TokenType::PRIVATE: {
			functionFlags |= FunctionFlags::FUNC_PRIVATE;
			break;
		}
		case Lexer::TokenType::PROTECTED: {
			functionFlags |= FunctionFlags::FUNC_PROTECTED;
			break;
		}
		default:
			break;
	}
	if (context.annotationFlags & AnnotationFlags::AN_NO_CONSTRUCTOR) {
		throw ParserError(firstLine,
		                  "@no_constructor is only supported on classes");
	}
	if (context.annotationFlags & AnnotationFlags::AN_NATIVE_DATA) {
		throw ParserError(firstLine,
		                  "@native_data is only supported on classes");
	}
	if (context.annotationFlags & AnnotationFlags::AN_NO_EXTENDS) {
		throw ParserError(firstLine,
		                  "@no_extends is only supported on classes");
	}
	if (context.annotationFlags & AnnotationFlags::AN_NATIVE) {
		throw ParserError(firstLine, "@native is only supported on functions");
	} else if (clazz->classFlags & ClassFlags::CLASS_NATIVE_DATA) {
		throw ParserError(
		    firstLine,
		    "Class " + clazz->getName(compile) +
		        " is marked @native_data, so the constructor must be native");
	}
	if (context.annotationFlags & AnnotationFlags::AN_OVERRIDE) {
		throw ParserError(firstLine,
		                  "@override is only supported on functions");
	}
	if (context.annotationFlags & AnnotationFlags::AN_NO_OVERRIDE) {
		throw ParserError(firstLine,
		                  "@no_override is only supported on functions");
	}

	// Arguments
	if (!nextToken(&token, context.tokens, i)) {
		--i;
		throw ParserError(context.tokens[i].line, "Expected '(' but not found");
	}
	Parameter *parameter = nullptr;
	if (expect(token, Lexer::TokenType::LPAREN)) {
		if (firstLine != token->line) {
			throw ParserError(firstLine, "Expected '(' but not found");
		}
		parameter = loadListDeclaration(in_data, i);
		if (!parameter->parameterDefaultValues.empty() &&
		    !classInfo->genericData) {
			context.defaultValueParameter.push_back(parameter);
		}
		if (!nextToken(&token, context.tokens, i)) {
			--i;
			throw ParserError(context.tokens[i].line,
			                  "Expected body but not found");
		}
	} else {
		parameter = context.parameterPool.push();
	}
	// listDeclarationNode.insert(listDeclarationNode.begin(),
	// context.getCurrentClassInfo(in_data)->declarationThis);
	// Body
	if (expect(token, Lexer::TokenType::LBRACE)) {
		if (functionFlags & FunctionFlags::FUNC_IS_NATIVE) {
			--i;
			throw ParserError(firstLine,
			                  "@native function must not have a body");
		}
	} else {
		--i;
		if (!(functionFlags & FunctionFlags::FUNC_IS_NATIVE)) {
			throw ParserError(context.tokens[i].line,
			                  "Expected body but not found");
		}
	}
	// Create constructor
	parameter->parameters.insert(parameter->parameters.begin(),
	                             classInfo->declarationThis);
	parameter->defaultValuePos += 1;
	auto constructor = context.createConstructorPool.push(
	    firstLine, *context.currentClassId,
	    context.lexerStringMap[clazz->getName(compile)], parameter, false,
	    functionFlags);
	classInfo->secondaryConstructor.push_back(constructor);
	constructor->pushFunction(in_data);
	context.gotoFunction(constructor->funcId);
	auto func = compile.functions[constructor->funcId];
	auto funcInfo = context.functionInfo[constructor->funcId];
	// compile
	//     .funcMap[compile.classes[*context.currentClassId]->getName(compile) +
	//     "." +
	//              compile.classes[*context.currentClassId]->getName(compile)]
	//     .push_back(constructor->funcId);

	if (functionFlags & FunctionFlags::FUNC_IS_NATIVE) {
		auto &token = context.annotationMetadata[AnnotationFlags::AN_NATIVE];
		const auto &name = context.lexerString[token.indexData];

		auto it = context.mode->nativeFuncMap.find(name);
		if (it == context.mode->nativeFuncMap.end()) {
			throw ParserError(firstLine, "Native function name '" + name +
			                                 "' could not be found");
		}
		// for (size_t j = 1; j < constructor->parameter->parameters.size();
		// ++j) { 	auto *param = constructor->parameter->parameters[j];
		// param->id = j;
		// }
		func->native = &it->second;
	} else {
		// Add to scope
		auto &scope = funcInfo->scopes.back();
		scope[lexerIdthis] = classInfo->declarationThis;

		// context.getCurrentFunctionInfo(in_data)->declaration = 1;
		for (size_t j = 0; j < constructor->parameter->parameters.size(); ++j) {
			auto *param = constructor->parameter->parameters[j];
			scope[param->baseName] = param;
			param->id = j;
		}
		loadBody<false>(in_data, constructor->body.nodes, i, false);
	}
	context.gotoFunction(context.mainFunctionId);
}

} // namespace AutoLang

#endif