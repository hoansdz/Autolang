#ifndef DEBUGGER_ANNOTATIONS_CPP
#define DEBUGGER_ANNOTATIONS_CPP

#include "Debugger.hpp"
#include "frontend/ACompiler.hpp"
#include "frontend/parser/ParserContext.hpp"
#include <filesystem>

namespace AutoLang {

void loadAnnotations(in_func, size_t &i) {
	Lexer::Token *token = &context.tokens[i];
	uint32_t firstLine = token->line;
	if (!nextTokenSameLine(&token, context.tokens, i, firstLine)) {
		std::cerr << ((int)(token->type == Lexer::TokenType::AT_SIGN)) << " "
		          << token->line << "\n";
		--i;
		throw ParserError(firstLine, "Expected annotation name after '@'");
	}
	switch (token->type) {
		case Lexer::TokenType::OVERRIDE: {
			if (context.annotationFlags & AnnotationFlags::AN_OVERRIDE) {
				throw ParserError(firstLine, "Duplicate annotation @override");
			}
			context.annotationFlags |= AnnotationFlags::AN_OVERRIDE;
			if (!nextToken(&token, context.tokens, i)) {
				--i;
				throw ParserError(context.tokens[i].line,
				                  "@override must be followed by a function");
			}
			--i;
			break;
		}
		case Lexer::TokenType::NO_OVERRIDE: {
			if (context.annotationFlags & AnnotationFlags::AN_NO_OVERRIDE) {
				throw ParserError(firstLine,
				                  "Duplicate annotation @no_override");
			}
			context.annotationFlags |= AnnotationFlags::AN_NO_OVERRIDE;
			if (!nextToken(&token, context.tokens, i)) {
				--i;
				throw ParserError(
				    context.tokens[i].line,
				    "@no_override must be followed by a function");
			}
			--i;
			break;
		}
		case Lexer::TokenType::WAIT_INPUT: {
			if (context.annotationFlags & AnnotationFlags::AN_WAIT_INPUT) {
				throw ParserError(firstLine,
				                  "Duplicate annotation @wait_input");
			}
			context.annotationFlags |= AnnotationFlags::AN_WAIT_INPUT;
			if (!nextToken(&token, context.tokens, i)) {
				--i;
				throw ParserError(context.tokens[i].line,
				                  "@wait_input must be followed by a function");
			}
			--i;
			break;
		}
		case Lexer::TokenType::NATIVE: {
			if (context.annotationFlags & AnnotationFlags::AN_NATIVE) {
				throw ParserError(firstLine, "Duplicate annotation @native");
			}
			context.annotationFlags |= AnnotationFlags::AN_NATIVE;
			if (!nextTokenSameLine(&token, context.tokens, i, firstLine) ||
			    !expect(token, Lexer::TokenType::LPAREN)) {
				--i;
				throw ParserError(firstLine, "@native expects a string value");
			}
			if (!nextTokenSameLine(&token, context.tokens, i, firstLine) ||
			    !expect(token, Lexer::TokenType::STRING)) {
				throw ParserError(firstLine, "@native expects a string value");
			}
			context.annotationMetadata[AnnotationFlags::AN_NATIVE] = *token;
			if (!nextTokenSameLine(&token, context.tokens, i, firstLine) ||
			    !expect(token, Lexer::TokenType::RPAREN)) {
				--i;
				throw ParserError(firstLine, "@native expects a constant "
				                             "string value, not an expression");
			}
			if (!nextToken(&token, context.tokens, i)) {
				--i;
				throw ParserError(context.tokens[i].line,
				                  "@native must be followed by a function");
			}
			--i;
			break;
		}
		case Lexer::TokenType::NO_CONSTRUCTOR: {
			if (context.annotationFlags & AnnotationFlags::AN_NO_CONSTRUCTOR) {
				throw ParserError(firstLine,
				                  "Duplicate annotation @no_constructor");
			}
			context.annotationFlags |= AnnotationFlags::AN_NO_CONSTRUCTOR;
			if (!nextToken(&token, context.tokens, i)) {
				--i;
				throw ParserError(
				    context.tokens[i].line,
				    "@no_constructor must be followed by a class");
			}
			--i;
			break;
		}
		case Lexer::TokenType::NO_EXTENDS: {
			if (context.annotationFlags & AnnotationFlags::AN_NO_EXTENDS) {
				throw ParserError(firstLine,
				                  "Duplicate annotation @no_extends");
			}
			context.annotationFlags |= AnnotationFlags::AN_NO_EXTENDS;
			if (!nextToken(&token, context.tokens, i)) {
				--i;
				throw ParserError(context.tokens[i].line,
				                  "@no_extends must be followed by a class");
			}
			--i;
			break;
		}
		case Lexer::TokenType::NATIVE_DATA: {
			if (context.annotationFlags & AnnotationFlags::AN_NATIVE_DATA) {
				throw ParserError(firstLine,
				                  "Duplicate annotation @native_data");
			}
			context.annotationFlags |= AnnotationFlags::AN_NATIVE_DATA;
			if (!nextToken(&token, context.tokens, i)) {
				--i;
				throw ParserError(context.tokens[i].line,
				                  "@native_data must be followed by a class");
			}
			--i;
			break;
		}
#ifdef __EMSCRIPTEN__
		case Lexer::TokenType::JS_OBJECT: {
			if (context.annotationFlags & AnnotationFlags::AN_JS_OBJECT) {
				throw ParserError(firstLine,
				                  "Duplicate annotation @js_object");
			}
			context.annotationFlags |= AnnotationFlags::AN_JS_OBJECT;
			if (!nextToken(&token, context.tokens, i)) {
				--i;
				throw ParserError(context.tokens[i].line,
				                  "@js_object must be followed by a class");
			}
			--i;
			break;
		}
#elif __PYBIND11__
        case Lexer::TokenType::PY_OBJECT: {
            if (context.annotationFlags & AnnotationFlags::AN_PY_OBJECT) {
                throw ParserError(firstLine,
                                  "Duplicate annotation @py_object");
            }
            context.annotationFlags |= AnnotationFlags::AN_PY_OBJECT;
            if (!nextToken(&token, context.tokens, i)) {
                --i;
                throw ParserError(context.tokens[i].line,
                                  "@py_object must be followed by a class");
            }
            --i;
            break;
        }
#endif
		case Lexer::TokenType::IMPORT: {
			if (!nextTokenSameLine(&token, context.tokens, i, firstLine) ||
			    !expect(token, Lexer::TokenType::LPAREN)) {
				--i;
				throw ParserError(
				    firstLine, "Bug: @import is missing opening '(' bracket");
			}
			if (!nextTokenSameLine(&token, context.tokens, i, firstLine) ||
			    !expect(token, Lexer::TokenType::STRING)) {
				throw ParserError(firstLine,
				                  "Bug: @import is missing a string argument");
			}
			std::string path = context.lexerString[token->indexData];
			if (path[0] == '.') {
				std::filesystem::path input = path;
				std::filesystem::path currentPath;
				if (context.mode->flags & LibraryFlags::IS_FILE) {
					currentPath =
					    std::filesystem::path(context.mode->path).parent_path();
				} else {
					currentPath = std::filesystem::current_path();
				}
				std::filesystem::path resolved =
				    (currentPath / input).lexically_normal();
				path = resolved.string();
			}
			bool mustAppend =
			    context.importMap.find(path) == context.importMap.end();
			if (!nextTokenSameLine(&token, context.tokens, i, firstLine) ||
			    !expect(token, Lexer::TokenType::RPAREN)) {
				--i;
				throw ParserError(
				    firstLine, "Bug: @import is missing closing ')' bracket");
			}
			if (!mustAppend)
				break;
			auto it =
			    context.mainLexerContext->library->dependencies.find(path);
			if (it == context.mainLexerContext->library->dependencies.end()) {
				throw ParserError(firstLine,
				                  "Bug: Library '" +
				                      context.mainLexerContext->library->path +
				                      "' is missing dependency '" + path + "'");
			}
			auto library = it->second;
			context.mode = library;
			context.importMap[path] = library;
			context.loadingLibs.push_back(library);
			context.tokens.insert(context.tokens.begin() + i + 1,
			                      library->lexerContext.tokens.begin(),
			                      library->lexerContext.tokens.end());
			// for (auto &token : context.tokens) {
			// 	std::cerr << token.toString(context) << " ";
			// }
			// std::cerr << "\n";
			break;
		}
		default: {
			throw ParserError(firstLine, "Unknown annotation '@" +
			                                 token->toString(context) + "'");
		}
	}
}

} // namespace AutoLang

#endif