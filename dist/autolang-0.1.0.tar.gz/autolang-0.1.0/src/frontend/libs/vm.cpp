#ifndef LIBS_VM_CPP
#define LIBS_VM_CPP

#include "frontend/ACompiler.hpp"
#include "shared/DefaultOperator.hpp"
#include <chrono>
#include <string>


namespace AutoLang {
class ACompiler;
namespace Libs {
namespace vm {

AObject *count_area_object(NativeFuncInData) {
	return notifier.createInt(
	    notifier.vm->data.manager.areaAllocator.countObject);
}

void init(ACompiler &compiler) {
	compiler.registerBuiltInLibrary("std/vm", R"###(
@no_constructor
class VM {
	@native("count_area_object")
	static fun getCountAreaAllocatorObject(): Int
}
	)###",
	                            LibraryConfig(),
	                            ANativeMap({
	                                {"count_area_object", &count_area_object},
	                            }));
}

} // namespace vm
} // namespace Libs
} // namespace AutoLang

#endif
