#ifndef LEXER_HPP
#define LEXER_HPP

#include "shared/Type.hpp"
#include "third_party/ankerl/unordered_dense.h"
#include <exception>
#include <fstream>
#include <iostream>
#include <vector>

#define AUTOLANG_DEBUG_

inline void printDebug(std::string msg) {
#ifdef AUTOLANG_DEBUG
	std::cerr << msg << '\n';
#endif
}

inline void printDebug(long msg) {
#ifdef AUTOLANG_DEBUG
	std::cerr << msg << '\n';
#endif
}

namespace AutoLang {

struct LibraryData;
struct ParserContext;

namespace Lexer {

enum TokenType : uint8_t {
	COMMENT_SINGLE_LINE,
	// ===== Literals =====
	NUMBER,
	STRING,
	IDENTIFIER,

	START_COMMENT,

	// ===== Operators =====
	PLUS,
	PLUS_PLUS,
	MINUS,
	MINUS_MINUS,
	STAR,
	SLASH,
	PERCENT,
	EQUAL,
	PLUS_EQUAL,
	MINUS_EQUAL,
	STAR_EQUAL,
	SLASH_EQUAL,
	PERCENT_EQUAL,

	// ===== Comparisons =====
	EQEQ,
	NOTEQ,
	EQEQEQ,
	NOTEQEQ,
	LT,
	GT,
	LTE,
	GTE,

	// ===== Logical operators =====
	AND_AND,
	OR_OR,

	// ===== Delimiters =====
	LPAREN,
	RPAREN,
	LBRACE,
	RBRACE,
	LBRACKET,
	RBRACKET,
	COMMA,
	DOT,
	QMARK_DOT, //    Dấu ?.
	DOT_DOT,
	DOT_DOT_LT,
	SEMICOLON,
	COLON,
	QMARK, //   Dấu hỏi chấm
	QMARK_QMARK,
	EXMARK,  //   Dấu chấm than
	AT_SIGN, // @

	// ===== Keywords =====
	IF,
	ELSE,
	WHILE,
	FOR,
	FUNC,
	RETURN,
	VAL,
	VAR,
	BREAK,
	CONTINUE,
	NOT,
	AND,
	OR,
	IN_,
	PUBLIC,
	PRIVATE,
	PROTECTED,
	CLASS,
	CONSTRUCTOR,
	STATIC,
	TRY,
	CATCH,
	THROW,
	EXTENDS,
	NATIVE,
#ifdef __EMSCRIPTEN__
	JS_OBJECT,
#elif __PYBIND11__
	PY_OBJECT,
#endif
	OVERRIDE,
	NO_OVERRIDE,
	NO_CONSTRUCTOR,
	NO_EXTENDS,
	NATIVE_DATA,
	IMPORT,
	END_IMPORT,
	WAIT_INPUT,
	IS,
	SAFE_CAST,
	UNSAFE_CAST,
	LATEINIT,
	ENUM,
	SEMI_COLON,
	CONST,
	WHEN,
	MINUS_GT,

	// ===== Special =====
	END_OF_FILE,
	INVALID
};

static const HashMap<std::string, TokenType> CAST = {
    {"var", TokenType::VAR},
    {"val", TokenType::VAL},
    {"not", TokenType::NOT},
    {"while", TokenType::WHILE},
    {"if", TokenType::IF},
    {"else", TokenType::ELSE},
    {"and", TokenType::AND_AND},
    {"for", TokenType::FOR},
    {"in", TokenType::IN_},
    {"or", TokenType::OR_OR},
    {"fun", TokenType::FUNC},
    {"return", TokenType::RETURN},
    {"continue", TokenType::CONTINUE},
    {"break", TokenType::BREAK},
    {"try", TokenType::TRY},
    {"catch", TokenType::CATCH},
    {"throw", TokenType::THROW},
    {"class", TokenType::CLASS},
    {"static", TokenType::STATIC},
    {"private", TokenType::PRIVATE},
    {"public", TokenType::PUBLIC},
    {"protected", TokenType::PROTECTED},
    {"constructor", TokenType::CONSTRUCTOR},
    {"extends", TokenType::EXTENDS},
    {"native", TokenType::NATIVE},
#ifdef __EMSCRIPTEN__
    {"js_object", TokenType::JS_OBJECT},
#elif __PYBIND11__
    {"py_object", TokenType::PY_OBJECT},
#endif
    {"override", TokenType::OVERRIDE},
    {"no_override", TokenType::NO_OVERRIDE},
    {"no_constructor", TokenType::NO_CONSTRUCTOR},
    {"no_extends", TokenType::NO_EXTENDS},
    {"native_data", TokenType::NATIVE_DATA},
    {"import", TokenType::IMPORT},
    {"is", TokenType::IS},
    {"as", TokenType::UNSAFE_CAST},
    {"wait_input", TokenType::WAIT_INPUT},
    {"lateinit", TokenType::LATEINIT},
    {"enum", TokenType::ENUM},
    {"const", TokenType::CONST},
    {"when", TokenType::WHEN},

    {"/*", TokenType::START_COMMENT},
    {"&", TokenType::AND},
    {"|", TokenType::OR},
    {"&&", TokenType::AND_AND},
    {"||", TokenType::OR_OR},
    {"//", TokenType::COMMENT_SINGLE_LINE},
    {"?", TokenType::QMARK},
    {"?.", TokenType::QMARK_DOT},
    {"??", TokenType::QMARK_QMARK},
    {"!", TokenType::EXMARK},
    {".", TokenType::DOT},
    {"..", TokenType::DOT_DOT},
    {"..<", TokenType::DOT_DOT_LT},
    {"+", TokenType::PLUS},
    {"++", TokenType::PLUS_PLUS},
    {"-", TokenType::MINUS},
    {"--", TokenType::MINUS_MINUS},
    {"*", TokenType::STAR},
    {"/", TokenType::SLASH},
    {"%", TokenType::PERCENT},
    {"+=", TokenType::PLUS_EQUAL},
    {"-=", TokenType::MINUS_EQUAL},
    {"*=", TokenType::STAR_EQUAL},
    {"/=", TokenType::SLASH_EQUAL},
    {"=", TokenType::EQUAL},
    {"<", TokenType::LT},
    {">", TokenType::GT},
    {"==", TokenType::EQEQ},
    {"!=", TokenType::NOTEQ},
    {"===", TokenType::EQEQEQ},
    {"!==", TokenType::NOTEQEQ},
    {">=", TokenType::GTE},
    {"<=", TokenType::LTE},
    {"->", TokenType::MINUS_GT},
};

struct Token {
	uint32_t line;
	LexerStringId indexData;
	TokenType type;
	Token() {}
	Token(uint32_t line, TokenType type, LexerStringId indexData)
	    : line(line), indexData(indexData), type(type) {}
	Token(uint32_t line, TokenType type)
	    : line(line), indexData(0), type(type) {}
	std::string toString(ParserContext &context);
};

class LexerError : public std::exception {
  public:
	uint32_t line;
	std::string message;
	LexerError(uint32_t line, std::string msg)
	    : line(line), message(std::move(msg)) {}
	const char *what() const noexcept override { return message.c_str(); }
};

struct Estimate {
	uint32_t declaration = 0;
	uint32_t classes = 0;
	uint32_t functions = 0;
	uint32_t constructorNode = 0;
	// uint32_t ifNode = 0;
	// uint32_t whileNode = 0;
	// uint32_t returnNode = 0;
	// uint32_t setNode = 0;
	// uint32_t binaryNode = 0;
	// uint32_t tryCatchNode = 0;
	// uint32_t throwNode = 0;
};

struct Context {
	ParserContext *mainContext;
	const char *line;
	size_t lineSize;
	size_t nextLinePosition = 0;
	size_t totalSize;
	uint32_t linePos;
	uint32_t pos;
	uint32_t absolutePos;
	std::vector<char> bracketStack;
	std::vector<Token> tokens;
	LibraryData *library;
	std::vector<Offset> *importOffset;

	bool hasError = false;

	Estimate estimate;
	Context() {
		tokens.reserve(256);
		bracketStack.reserve(16);
	}
	inline void refresh() {
		bracketStack.clear();
		tokens.clear();
		hasError = false;
	}
};

inline bool nextLine(Context &context, const char *lines, uint32_t &i);
inline bool isOperator(char chr);
inline bool isEndOfLine(Context &context, uint32_t i);
void loadFile(ParserContext *mainContext, LibraryData *library);
void load(ParserContext *mainContext, LibraryData *library,
          std::vector<Offset> *importOffset);
template <bool addLParen, bool isChar, bool isRawString>
inline void loadQuote(Context &context, uint32_t &i);
std::string loadIdentifier(Context &context, uint32_t &i);
std::string loadNumber(Context &context, uint32_t &i);
inline TokenType loadOp(Context &context, uint32_t &i);
inline bool loadNextTokenNoCloseBracket(Context &context, uint32_t &i);
inline void pushAndEnsureBracket(Context &context, uint32_t &i);
inline void pushIdentifier(Context &context, uint32_t &i);
inline uint32_t pushLexerString(Context &context, std::string &&str);
inline char getCloseBracket(char chr);

} // namespace Lexer
} // namespace AutoLang

#endif