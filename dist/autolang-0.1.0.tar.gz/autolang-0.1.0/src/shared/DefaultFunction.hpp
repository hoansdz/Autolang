#ifndef DEFAULT_FUNCTION_HPP
#define DEFAULT_FUNCTION_HPP

#include "backend/libs/array.hpp"
#include "backend/libs/map.hpp"
#include "backend/libs/set.hpp"
#include "backend/vm/ANotifier.hpp"
#include "frontend/libs/math.hpp"
#include "frontend/parser/Debugger.hpp"
#include "shared/DefaultClass.hpp"
#include <cstdlib>
#include <iostream>
#include <sstream>

namespace AutoLang {
class ACompiler;
namespace DefaultFunction {

void init(ACompiler &compiler);
inline AObject *data_constructor(NativeFuncInData);
inline AObject *print(NativeFuncInData);
inline AObject *println(NativeFuncInData);
inline AObject *get_refcount(NativeFuncInData);
inline AObject *string_constructor(NativeFuncInData);
inline AObject *to_int(NativeFuncInData);
inline AObject *to_float(NativeFuncInData);
inline AObject *trim(NativeFuncInData);
inline AObject *to_string(NativeFuncInData);
inline std::string to_string(ANotifier &notifier, AObject *obj,
                             std::string space = std::string());
inline AObject *get_string_size(NativeFuncInData);
inline AObject *input_str(NativeFuncInData);
inline AObject *str_get(NativeFuncInData);
inline AObject *str_set(NativeFuncInData);
inline AObject *str_char_at(NativeFuncInData);

AObject *data_constructor(NativeFuncInData) {
	AObject *obj = args[0];
	for (size_t i = 1; i < argSize; ++i) {
		AObject **last = &obj->member->data[i - 1];
		*last = args[i];
		(*last)->retain();
	}
	return nullptr;
}

std::string to_string(ANotifier &notifier, AObject *obj, std::string space) {
	if (!obj) {
		return "c_nullptr";
	}
	uint32_t type = obj->type;
	switch (type) {
		case AutoLang::DefaultClass::intClassId:
			return std::to_string(obj->i);
		case AutoLang::DefaultClass::floatClassId:
			return std::to_string(obj->f);
		case AutoLang::DefaultClass::stringClassId:
			return std::string(obj->str->data);
		case AutoLang::DefaultClass::nullClassId:
			return "null";
		case DefaultClass::boolClassId:
			return (obj == DefaultClass::trueObject ? "true" : "false");
		default:
			if (obj->flags & AObject::Flags::OBJ_IS_ARRAY) {
				return Libs::array::to_string(notifier, obj);
			}
			if (obj->flags & AObject::Flags::OBJ_IS_SET) {
				return Libs::set::to_string(notifier, obj);
			}
			if (obj->flags & AObject::Flags::OBJ_IS_MAP) {
				return Libs::map::to_string(notifier, obj);
			}
			auto clazz = notifier.vm->data.classes[obj->type];
			auto allFuncToString = clazz->funcMap["toString"];
			for (FunctionId id : allFuncToString) {
				auto func = notifier.vm->data.functions[id];
				if (func->argSize != 1 ||
				    (func->functionFlags & FunctionFlags::FUNC_IS_STATIC)) {
					continue;
				}
				if (func->returnId != DefaultClass::stringClassId) {
					break;
				}
				auto data = notifier.callFunction(func, obj);
				if (notifier.hasException()) {
					return "";
				}
				std::string result = data->str->data;
				notifier.release(data);
				return result;
			}

			std::string newSpace = space + "  ";

			if (obj->flags & AObject::Flags::OBJ_HAS_MEMBER_DATA) {
				std::string result =
				    clazz->getName(notifier.vm->data) + " (\n" + newSpace;
				bool isFirst = true;
				for (auto &[memberName, id] : clazz->memberMap) {
					if (isFirst) {
						isFirst = false;
					} else {
						result += ",\n" + newSpace;
					}
					std::string str =
					    to_string(notifier, obj->member->data[id], newSpace);
					result += memberName + " : " + std::move(str);
				}
				result += "\n" + space + ")";
				return result;
			}
			std::stringstream ss;
			ss << clazz->getName(notifier.vm->data) << "@" << obj;
			return ss.str();
	}
}

inline AObject *print(NativeFuncInData) {
	AObject *obj = args[0];
	std::cerr << to_string(notifier, obj);
	return nullptr;
}

AObject *println(NativeFuncInData) {
	AObject *obj = args[0];
	std::cerr << to_string(notifier, obj) << "\n";
	return nullptr;
}

AObject *get_refcount(NativeFuncInData) {
	return notifier.createInt(static_cast<int64_t>(args[0]->refCount - 1));
}

AObject *to_int(NativeFuncInData) {
	auto obj = args[0];
	switch (obj->type) {
		case AutoLang::DefaultClass::intClassId:
			return notifier.createInt(obj->i);
		case AutoLang::DefaultClass::floatClassId:
			return notifier.createInt(static_cast<int64_t>(obj->f));
		case AutoLang::DefaultClass::boolClassId:
			return notifier.createInt(static_cast<int64_t>(obj->b));
		case AutoLang::DefaultClass::stringClassId: {
			char *end;
			return notifier.createInt(std::strtoll(obj->str->data, &end, 10));
		}
		default:
			break;
	}
	notifier.throwException("Cannot cast '" + notifier.getClassName(obj->type) +
	                        "' to 'Int'");
	return nullptr;
}

AObject *to_float(NativeFuncInData) {
	auto obj = args[0];
	switch (obj->type) {
		case AutoLang::DefaultClass::intClassId:
			return notifier.createFloat(static_cast<double>(obj->i));
		case AutoLang::DefaultClass::floatClassId:
			return notifier.createFloat(obj->f);
		case AutoLang::DefaultClass::boolClassId:
			return notifier.createFloat(static_cast<double>(obj->b));
		case AutoLang::DefaultClass::stringClassId: {
			// Check error but unused
			char *end;
			return notifier.createFloat(std::strtod(obj->str->data, &end));
		}
		default:
			break;
	}
	notifier.throwException("Cannot cast '" + notifier.getClassName(obj->type) +
	                        "' to 'Float'");
	return nullptr;
}

AObject *to_string(NativeFuncInData) {
	auto obj = args[0];
	switch (obj->type) {
		case AutoLang::DefaultClass::intClassId:
			return notifier.createString(AString::from(obj->i));
		case AutoLang::DefaultClass::floatClassId:
			return notifier.createString(AString::from(obj->f));
		case AutoLang::DefaultClass::stringClassId:
			return notifier.createString(AString::copy(obj->str));
		default:
			break;
	}
	notifier.throwException("Cannot cast '" + notifier.getClassName(obj->type) +
	                        "' to 'String'");
	return nullptr;
}

AObject *str_trim(NativeFuncInData) {
	const std::string &s = args[0]->str->data;
	size_t start = s.find_first_not_of(" \n\r\t");
	if (start == std::string::npos) {
		return notifier.createString("");
	}
	size_t end = s.find_last_not_of(" \n\r\t");
	return notifier.createString(s.substr(start, end - start + 1));
}

AObject *string_constructor(NativeFuncInData) {
	switch (argSize) {
		case 0: {
			char *newStr = new char[1];
			newStr[0] = '\0';
			return notifier.createString(new AString(newStr, 0));
		}
		// To string
		case 1: {
			return to_string(notifier, args, argSize);
		}
		//"hi",3 => "hihihi"
		case 2: {
			int64_t count = args[1]->i;
			AString *oldAStr = args[0]->str;
			if (count <= 0 || oldAStr->size == 0) {
				char *newStr = new char[1];
				newStr[0] = '\0';
				return notifier.createString(new AString(newStr, 0));
			}
			size_t newSize = oldAStr->size * count;
			char *newStr = new char[newSize + 1];
			for (int i = 0; i < count; ++i) {
				memcpy(&newStr[i * oldAStr->size], oldAStr->data,
				       oldAStr->size);
			}
			newStr[newSize] = '\0';
			return notifier.createString(new AString(newStr, newSize));
		}
		default: {
			notifier.throwException("Cannot create String");
			return nullptr;
		}
	}
}

AObject *str_get(NativeFuncInData) {
	AString *str = args[0]->str;
	int64_t pos = args[1]->i;

	int64_t len = str->size;

	if (len == 0) {
		notifier.throwException("Empty string");
		return nullptr;
	}

	if (pos < 0)
		pos += len;

	if (pos < 0 || pos >= len) {
		notifier.throwException("Index out of range");
		return nullptr;
	}

	return notifier.createString(AString::from(str->data[pos]));
}

inline AObject *str_starts_with(NativeFuncInData) {
    AString *str = args[0]->str;
    AString *prefix = args[1]->str;
    if (prefix->size > str->size) return DefaultClass::falseObject;
    return notifier.createBool(std::memcmp(str->data, prefix->data, prefix->size) == 0);
}

inline AObject *str_ends_with(NativeFuncInData) {
    AString *str = args[0]->str;
    AString *suffix = args[1]->str;
    if (suffix->size > str->size) return DefaultClass::falseObject;
    return notifier.createBool(std::memcmp(str->data + str->size - suffix->size, suffix->data, suffix->size) == 0);
}

inline AObject *str_last_index_of(NativeFuncInData) {
    std::string_view full(args[0]->str->data, args[0]->str->size);
    std::string_view target(args[1]->str->data, args[1]->str->size);
    auto pos = full.rfind(target);
    if (pos == std::string_view::npos) return notifier.createInt(-1);
    return notifier.createInt(static_cast<int64_t>(pos));
}

inline AObject *str_to_lower(NativeFuncInData) {
    AString *str = args[0]->str;
    char *newStr = new char[str->size + 1];
    for (size_t i = 0; i < str->size; ++i) {
        char c = str->data[i];
        newStr[i] = (c >= 'A' && c <= 'Z') ? (c + 32) : c;
    }
    newStr[str->size] = '\0';
    return notifier.createString(new AString(newStr, str->size));
}

inline AObject *str_to_upper(NativeFuncInData) {
    AString *str = args[0]->str;
    char *newStr = new char[str->size + 1];
    for (size_t i = 0; i < str->size; ++i) {
        char c = str->data[i];
        newStr[i] = (c >= 'a' && c <= 'z') ? (c - 32) : c;
    }
    newStr[str->size] = '\0';
    return notifier.createString(new AString(newStr, str->size));
}

inline AObject *str_replace(NativeFuncInData) {
    std::string_view full(args[0]->str->data, args[0]->str->size);
    std::string_view oldStr(args[1]->str->data, args[1]->str->size);
    std::string_view newStr(args[2]->str->data, args[2]->str->size);

    if (oldStr.empty()) return notifier.createString(AString::copy(args[0]->str));

    size_t count = 0;
    size_t pos = 0;
    while ((pos = full.find(oldStr, pos)) != std::string_view::npos) {
        ++count;
        pos += oldStr.length();
    }

    if (count == 0) return notifier.createString(AString::copy(args[0]->str));

    size_t newSize = full.length() + count * (newStr.length() - oldStr.length());
    char *resultStr = new char[newSize + 1];
    
    size_t writePos = 0;
    size_t readPos = 0;
    while ((pos = full.find(oldStr, readPos)) != std::string_view::npos) {
        size_t chunkLen = pos - readPos;
        std::memcpy(resultStr + writePos, full.data() + readPos, chunkLen);
        writePos += chunkLen;
        std::memcpy(resultStr + writePos, newStr.data(), newStr.length());
        writePos += newStr.length();
        readPos = pos + oldStr.length();
    }
    std::memcpy(resultStr + writePos, full.data() + readPos, full.length() - readPos);
    resultStr[newSize] = '\0';

    return notifier.createString(new AString(resultStr, newSize));
}

// AObject *str_set(NativeFuncInData) {
// 	AString *str = args[0]->str;
// 	int64_t pos = args[1]->i;
// 	AObject *obj = args[2];

// 	int64_t len = str->size;

// 	if (len == 0) {
// 		notifier.throwException("Empty string");
// 		return nullptr;
// 	}

// 	if (pos < 0)
// 		pos += len;

// 	if (pos < 0 || pos >= len) {
// 		notifier.throwException("Index out of range");
// 		return nullptr;
// 	}

// 	switch (obj->type) {
// 		case DefaultClass::intClassId: {
// 			if (obj->i < 0 || obj->i > 255) {
// 				notifier.throwException("Char must be [0, 255]");
// 				return nullptr;
// 			}
// 			notifier.createString()
// 			str->data[pos] = static_cast<char>(obj->i);
// 			return nullptr;
// 		}
// 		default: {

// 		}
// 	}

// 	return notifier.createString(AString::from(str->data[pos]));
// }

AObject *str_char_at(NativeFuncInData) {
	AString *str = args[0]->str;
	int64_t pos = args[1]->i;

	int64_t len = str->size;

	if (len == 0) {
		notifier.throwException("Empty string");
		return nullptr;
	}

	if (pos < 0)
		pos += len;

	if (pos < 0 || pos >= len) {
		notifier.throwException("Index out of range");
		return nullptr;
	}

	return notifier.createInt(str->data[pos]);
}

AObject *str_contains(NativeFuncInData) {
	AString *str = args[0]->str;
	AString *sub = args[1]->str;

	std::string_view full(str->data, str->size);
	std::string_view target(sub->data, sub->size);

	bool found = full.find(target) != std::string_view::npos;
	return found ? DefaultClass::trueObject : DefaultClass::falseObject;
}

AObject *str_index_of(NativeFuncInData) {
	AString *str = args[0]->str;
	AString *sub = args[1]->str;

	std::string_view full(str->data, str->size);
	std::string_view target(sub->data, sub->size);

	auto pos = full.find(target);
	if (pos == std::string_view::npos) {
		return notifier.createInt(-1);
	}
	return notifier.createInt(static_cast<int64_t>(pos));
}

AObject *str_is_empty(NativeFuncInData) {
	AString *str = args[0]->str;
	return notifier.createBool(str->size == 0);
}

AObject *str_split(NativeFuncInData) {
	std::string full(args[0]->str->data, args[0]->str->size);
	std::string delim(args[1]->str->data, args[1]->str->size);
	ClassId classId = args[2]->i;

	AObject *arrayObj = notifier.createArray(classId);

	if (delim.empty()) {
		notifier.arrayAdd(arrayObj,
		                  notifier.createString(AString::copy(args[0]->str)));
		return arrayObj;
	}

	size_t start = 0;
	size_t end = full.find(delim);
	while (end != std::string::npos) {
		std::string token = full.substr(start, end - start);
		notifier.arrayAdd(arrayObj,
		                  notifier.createString(AString::from(token)));
		start = end + delim.length();
		end = full.find(delim, start);
	}
	notifier.arrayAdd(arrayObj,
	                  notifier.createString(AString::from(full.substr(start))));

	return arrayObj;
}

AObject *str_substr(NativeFuncInData) {
	AString *str = args[0]->str;
	int64_t len = str->size;

	if (argSize < 2 || argSize > 3) {
		notifier.throwException("substr expects 1 or 2 arguments");
		return nullptr;
	}

	int64_t from = args[1]->i;

	if (from < 0)
		from += len;

	if (from < 0 || from > len) {
		notifier.throwException("Index out of range");
		return nullptr;
	}

	// substr(from)
	if (argSize == 2) {
		int64_t newLen = len - from;

		char *newStr = new char[newLen + 1];
		memcpy(newStr, str->data + from, newLen);
		newStr[newLen] = '\0';

		return notifier.createString(new AString(newStr, newLen));
	}

	// substr(from, length)
	int64_t length = args[2]->i;

	if (length < 0) {
		notifier.throwException("Length cannot be negative");
		return nullptr;
	}

	if (from + length > len)
		length = len - from;

	char *newStr = new char[length + 1];
	memcpy(newStr, str->data + from, length);
	newStr[length] = '\0';

	return notifier.createString(new AString(newStr, length));
}

AObject *get_string_size(NativeFuncInData) {
	return notifier.createInt(static_cast<int64_t>(args[0]->str->size));
}

AObject *input_str(NativeFuncInData) {
#ifdef __EMSCRIPTEN__

#else
	std::string s;
	std::getline(std::cin, s);
	notifier.input(notifier.createString(AString::from(s)));
#endif
	return nullptr;
}

} // namespace DefaultFunction
} // namespace AutoLang

#endif