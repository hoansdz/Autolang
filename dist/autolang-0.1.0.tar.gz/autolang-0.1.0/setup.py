import os
import sys
from setuptools import setup

try:
    from pybind11.setup_helpers import Pybind11Extension, build_ext
except ImportError:
    print("Vui lòng cài đặt pybind11 trước: pip install pybind11")
    sys.exit(1)

# Lấy đường dẫn tuyệt đối của project
BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# --- ĐOẠN HACK ĐỂ SỬA LỖI TRỘN CỜ MSVC VÀ MINGW ---
class build_ext_mingw_fix(build_ext):
    def build_extensions(self):
        compiler_type = self.compiler.compiler_type
        for ext in self.extensions:
            new_args = []
            for arg in ext.extra_compile_args:
                if compiler_type == 'mingw32':
                    if not arg.startswith('/') and not arg.startswith('-std='):
                        new_args.append(arg)
                else:
                    if not arg.startswith('/') and not arg.startswith('-Wa,'):
                        new_args.append(arg)
            
            ext.extra_compile_args = ["-std=c++17"] + new_args
                
        super().build_extensions()

main_cpp = os.path.join(BASE_DIR, "tests/pybind11/main.cpp").replace("\\", "/")
src_dir = os.path.join(BASE_DIR, "src").replace("\\", "/")

source_files = [main_cpp]

include_dirs = [
    src_dir,
    os.path.join(src_dir, "third_party/curl/include").replace("\\", "/"),
    os.path.join(src_dir, "third_party").replace("\\", "/")
]

extra_compile_args = [
    "-std=c++17",
    "-O2",
    "-DNOMINMAX",
    "-DNO_INCLUDE_LIBS_HTTP", # Tắt thư viện HTTP để loại bỏ dependency curl/libcurl
    "-Wno-unused-parameter",
    "-Wno-unused-variable",
    "-Wno-switch",
    "-Wno-sign-compare",
    "-Wno-reorder",
    "-Wa,-mbig-obj"
]

extra_objects = []
libraries = []

if sys.platform == "win32":
    # Không cần libcurl.a tĩnh nữa
    libraries.extend(["ws2_32", "wldap32", "crypt32", "advapi32", "bcrypt"])
else:
    # Trên Linux/macOS không cần link lcurl động
    extra_compile_args = [arg for arg in extra_compile_args if not arg.startswith("-Wa,")]

ext_modules = [
    Pybind11Extension(
        "autolang",
        source_files,
        include_dirs=include_dirs,
        extra_compile_args=extra_compile_args,
        extra_objects=extra_objects,
        libraries=libraries,
        cxx_std=None,
    ),
]

setup(
    name="autolang",
    version="0.1.0",
    description="Python binding cho AutoLang",
    long_description=open("README.md", "r", encoding="utf-8", errors="ignore").read() if os.path.exists("README.md") else "",
    long_description_content_type="text/markdown",
    ext_modules=ext_modules,
    cmdclass={"build_ext": build_ext_mingw_fix},
    zip_safe=False,
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: C++",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)
